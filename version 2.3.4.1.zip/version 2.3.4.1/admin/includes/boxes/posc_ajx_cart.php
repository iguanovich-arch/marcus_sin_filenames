<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/
global $language;
include(DIR_WS_LANGUAGES . $language . '/posc_ajx_cart.php');
$posc_ajx_qr = tep_db_query("select * from " . TABLE_CONFIGURATION . " where configuration_key like 'POSC_AJXCART%' ");
$posc_ajx_cart_group = 89;
if($posc_ajx_qr->num_rows ==0){
	//tep_db_query("insert into " . TABLE_CONFIGURATION_GROUP . " (configuration_group_title, configuration_group_description, sort_order, visible) values ('Posc AjaxCart', 'Enable Posc AjxCart?', '89', 1)");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable Posc AjaxCart', 'POSC_AJXCART_STATUS', 'True', 'Do you want to add the module to your shop?', $posc_ajx_cart_group , '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Enable jQuery v1.12.4', 'POSC_AJXCART_JQUERY_STATUS', 'False', 'Enable jQuery?', $posc_ajx_cart_group, '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('Responsive Posc AjxCart Status', 'POSC_AJXCART_RESPONSIVE_STATUS', 'True', 'Enable AjxCart Insponsive.', $posc_ajx_cart_group, '1', 'tep_cfg_select_option(array(\'True\', \'False\'), ', now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('AjxCart Popup Width', 'POSC_AJXCART_POPUP_WIDTH', '365', 'AjxCart Popup Width. <br> default=365', $posc_ajx_cart_group, '1', NULL, now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('AjxCart Popup Height', 'POSC_AJXCART_POPUP_HEIGHT', 'auto', 'AjxCart Popup Height. <br> default=auto', $posc_ajx_cart_group, '1', NULL, now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('AjxCart Popup Image Width', 'POSC_AJXCART_POPUP_IMAGE_WIDTH', '200', 'AjxCart Popup Image Width. <br> default=200', $posc_ajx_cart_group, '1', NULL, now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('AjxCart Popup Image Height', 'POSC_AJXCART_POPUP_IMAGE_HEIGHT', 'auto', 'AjxCart Popup Image Height. <br> default=auto', $posc_ajx_cart_group, '1', NULL, now())");
	tep_db_query("insert into " . TABLE_CONFIGURATION . " (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, set_function, date_added) values ('AjxCart Popup Timeout', 'POSC_AJXCART_POPUP_TIMEOUT', '10000', 'AjxCart popup Timeout. Set this in milliseconds. <br> default=10000', $posc_ajx_cart_group, '1', NULL, now())");
}

$cl_box_groups[] = array(
    'heading' => 'Posc Ajax Cart',
    'apps' => array(
		array(
			'code' => 'posc_ajx_cart.php',
			'title' => 'Ajax Cart Settings',
			'link' => tep_href_link('configuration.php', 'gID=89')
		)
	)
);


?>
