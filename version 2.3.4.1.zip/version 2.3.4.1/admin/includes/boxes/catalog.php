<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  $cl_box_groups[] = array(
    'heading' => BOX_HEADING_CATALOG,
    'apps' => array(
      array(
        'code' => 'categories.php',
        'title' => BOX_CATALOG_CATEGORIES_PRODUCTS,
        'link' => tep_href_link('categories.php')
      ),
      array(
        'code' => FILENAME_PRODUCTS_ATTRIBUTES,
        'title' => BOX_CATALOG_CATEGORIES_PRODUCTS_ATTRIBUTES,
        'link' => tep_href_link(FILENAME_PRODUCTS_ATTRIBUTES)
      ),
	  array(
        'code' => FILENAME_PRODUCTS_EXTRA_VIDEOS,
        'title' => BOX_CATALOG_CATEGORIES_PRODUCTS_EXTRA_VIDEOS,
        'link' => tep_href_link(FILENAME_PRODUCTS_EXTRA_VIDEOS)
      ),
      array(
        'code' => 'manufacturers.php',
        'title' => BOX_CATALOG_MANUFACTURERS,
        'link' => tep_href_link('manufacturers.php')
      ),
      array(
        'code' => FILENAME_REVIEWS,
        'title' => BOX_CATALOG_REVIEWS,
        'link' => tep_href_link(FILENAME_REVIEWS)
      ),
      array(
        'code' => FILENAME_SPECIALS,
        'title' => BOX_CATALOG_SPECIALS,
        'link' => tep_href_link(FILENAME_SPECIALS)
      ),
	  // BOF: Featured Products
        array(
        'code' => FILENAME_FEATURED,
        'title' => BOX_CATALOG_FEATURED_PRODUCTS,
        'link' => tep_href_link(FILENAME_FEATURED)
      ),
      // EOF: Featured Products
      array(
        'code' => FILENAME_PRODUCTS_EXPECTED,
        'title' => BOX_CATALOG_PRODUCTS_EXPECTED,
        'link' => tep_href_link(FILENAME_PRODUCTS_EXPECTED)
      )
    )
  );
?>
