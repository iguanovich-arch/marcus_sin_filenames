<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

// define the filenames used in the project
  define(''action_recorder.php'', 'action_recorder.php');
  define(''administrators.php'', 'administrators.php');
  define(''backup.php'', 'backup.php');
  define(''banner_manager.php'', 'banner_manager.php');
  define(''banner_statistics.php'', 'banner_statistics.php');
  define(''cache.php'', 'cache.php');
  define(''account_history_info.php'', 'account_history_info.php');
  define(''categories.php'', 'categories.php');
  define(''configuration.php'', 'configuration.php');
  define(''countries.php'', 'countries.php');
  define(''currencies.php'', 'currencies.php');
  define(''customers.php'', 'customers.php');
  define(''index.php'', 'index.php');
  define(''define_language.php'', 'define_language.php');
  define(''geo_zones.php'', 'geo_zones.php');
  define(''languages.php'', 'languages.php');
  define(''login.php'', 'login.php');
  define(''mail.php'', 'mail.php');
  define(''manufacturers.php'', 'manufacturers.php');
  define(''modules.php'', 'modules.php');
  define(''newsletters.php'', 'newsletters.php');
  define(''orders.php'', 'orders.php');
  define(''invoice.php'', 'invoice.php');
  define(''packingslip.php'', 'packingslip.php');
  define('FILENAME_ORDERS_STATUS', 'orders_status.php');
  define('FILENAME_POPUP_IMAGE', 'popup_image.php');
  define('FILENAME_PRODUCTS_ATTRIBUTES', 'products_attributes.php');
  define('FILENAME_PRODUCTS_EXPECTED', 'products_expected.php');
  define('FILENAME_REVIEWS', 'reviews.php');
  define('FILENAME_SEC_DIR_PERMISSIONS', 'sec_dir_permissions.php');
  define('FILENAME_SERVER_INFO', 'server_info.php');
  define('FILENAME_SHIPPING_MODULES', 'shipping_modules.php');
  define('FILENAME_SPECIALS', 'specials.php');
  define('FILENAME_STATS_CUSTOMERS', 'stats_customers.php');
  define('FILENAME_STATS_PRODUCTS_PURCHASED', 'stats_products_purchased.php');
  define('FILENAME_STATS_PRODUCTS_VIEWED', 'stats_products_viewed.php');
  define('FILENAME_STORE_LOGO', 'store_logo.php');
  define('FILENAME_TAX_CLASSES', 'tax_classes.php');
  define('FILENAME_TAX_RATES', 'tax_rates.php');
  define('FILENAME_VERSION_CHECK', 'version_check.php');
  define('FILENAME_WHOS_ONLINE', 'whos_online.php');
  define('FILENAME_ZONES', 'zones.php');
  // BOF: Featured Products
  define('FILENAME_FEATURED', 'featured.php');
  define(''featured_products.php'', 'featured_products.php');
  define('FILENAME_SELECT_FEATURED', 'select_featured.php');
  define('FILENAME_PAGE_MANAGER', 'extra_info_pages.php');
  define('FILENAME_PRODUCTS_EXTRA_VIDEOS','products_extra_videos.php'); //Extra YouTube Videos
?>
