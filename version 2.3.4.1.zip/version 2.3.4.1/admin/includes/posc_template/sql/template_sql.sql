#
# PZEN TEMPLATE SQL
#

CREATE TABLE IF NOT EXISTS pzen_alto_template (
	opt_id int(11) NOT NULL AUTO_INCREMENT,
	lang_id int(11) NOT NULL DEFAULT '0',
	opt_name varchar(255) COLLATE utf8_unicode_ci NOT NULL,
	opt_value text COLLATE utf8_unicode_ci NOT NULL,
	PRIMARY KEY (opt_id)
);

INSERT INTO pzen_alto_template (opt_id, lang_id, opt_name, opt_value) VALUES
(1, 0, 'facebook_link', 'perfectusinc'),
(2, 0, 'twitter_link', 'perfectusinc'),
(3, 0, 'pinterest_link', 'envato'),
(4, 0, 'google_link', 'https://plus.google.com/'),
(5, 0, 'instagram_link', 'https://www.instagram.com/Envato/'),
(6, 0, 'header_style', 'tpl_header_v1'),
(7, 0, 'file_logo', 'logo_1501665158.png'),
(8, 0, 'file_favicon', 'favicon_1501665320.png'),
(9, 0, 'footer_style', 'footer_v1'),
(10, 0, 'store_copyright', '&amp;copy; 2017 PerfectusIn. All Rights Reserved'),
(11, 0, 'store_address', '262 Milacina Mrest Street Behansed, United State.'),
(12, 0, 'store_contact', '+84 3333 6789'),
(13, 0, 'store_fax', '84 3333 6789'),
(14, 0, 'store_skype', '84 3333 6789'),
(15, 0, 'store_email', 'contact@domain.com'),
(16, 0, 'footer_logo', 'logo_1501669999.png'),
(17, 0, 'newsletter_details', '&lt;!-- Begin MailChimp Signup Form --&gt;\r\n&lt;div id=&quot;mc_embed_signup&quot;&gt;\r\n&lt;form action=&quot;http://elegantdesignhub.us3.list-manage1.com/subscribe/post?u=aec0ecc511b9e4dec6925a777&amp;id=3f25e396e2&quot; method=&quot;post&quot; id=&quot;mc-embedded-subscribe-form&quot; name=&quot;mc-embedded-subscribe-form&quot; class=&quot;validate&quot; target=&quot;_blank&quot; novalidate&gt;\r\n&lt;label for=&quot;mce-EMAIL&quot;&gt;Sign up for our newsletter for exclusive updates on  new products, offers and more.&lt;/label&gt;\r\n	&lt;input type=&quot;email&quot; value=&quot;&quot; name=&quot;EMAIL&quot; class=&quot;email&quot; id=&quot;mce-EMAIL&quot; placeholder=&quot;email address&quot; required&gt;\r\n    &lt;!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups--&gt;\r\n    &lt;div style=&quot;position: absolute; left: -5000px;&quot;&gt;&lt;input type=&quot;text&quot; name=&quot;b_aec0ecc511b9e4dec6925a777_3f25e396e2&quot; tabindex=&quot;-1&quot; value=&quot;&quot;&gt;&lt;/div&gt;\r\n    &lt;div class=&quot;clear&quot;&gt;&lt;input type=&quot;submit&quot; value=&quot;Subscribe&quot; name=&quot;subscribe&quot; id=&quot;mc-embedded-subscribe&quot; class=&quot;btn btn--ys btn--xl&quot;&gt;&lt;/div&gt;\r\n&lt;/form&gt;\r\n&lt;/div&gt;'),
(18, 0, 'payment_image', 'payment_1501671528.png'),
(21, 0, 'prod_slider_addtionalimg_style', '2'),
(22, 0, 'prod_slider_nums_addimgs', '3'),
(23, 0, 'display_top_banners', '1'),
(25, 0, 'top_banners_style', '1'),
(26, 0, 'display_middle_banner', '1'),
(27, 1, 'middle_banner_caption', '&lt;div class=&quot;full-banner-text&quot;&gt;\r\n	&lt;h4&gt;&lt;a href=&quot;#&quot;&gt;Applique Prom Dress&lt;/a&gt;&lt;/h4&gt;\r\n	&lt;h3&gt;&lt;span&gt;From&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Dresses,&lt;/a&gt;&lt;a href=&quot;#&quot;&gt;Fashion&lt;/a&gt;&lt;/h3&gt;\r\n	&lt;div class=&quot;price&quot;&gt;\r\n		&lt;span class=&quot;old-price&quot;&gt;&lt;del&gt;$230.00&lt;/del&gt;&lt;/span&gt;\r\n		&lt;span class=&quot;new-price&quot;&gt;$210.00&lt;/span&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;timer&quot;&gt;\r\n		&lt;div data-countdown=&quot;2017/12/15&quot;&gt;&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;'),
(28, 0, 'middle_banner_image', 'hm1-mb_1505542174.jpg'),
(29, 0, 'display_testimonials', '1'),
(30, 0, 'testimonials_banner_image', 'testimonials_banner_1501837028.jpg'),
(31, 0, 'menu_type', '2'),
(32, 0, 'badge_type_114', '0'),
(33, 0, 'subcat_imgstatus_114', '0'),
(34, 0, 'megamenu_btype_114', '0'),
(35, 0, 'megamenu_btype_view_114', '2'),
(36, 0, 'megamenu_bottom_block_114', '0'),
(37, 0, 'mg_botban_cont_0_114_link', ''),
(38, 0, 'mg_botban_cont_1_114_link', ''),
(39, 0, 'badge_type_111', '0'),
(40, 0, 'subcat_imgstatus_111', '0'),
(41, 0, 'megamenu_btype_111', '0'),
(42, 0, 'megamenu_btype_view_111', '2'),
(43, 0, 'megamenu_bottom_block_111', '0'),
(44, 0, 'mg_botban_cont_0_111_link', ''),
(45, 0, 'mg_botban_cont_1_111_link', ''),
(46, 0, 'badge_type_112', '0'),
(47, 0, 'subcat_imgstatus_112', '0'),
(48, 0, 'megamenu_btype_112', '0'),
(49, 0, 'megamenu_btype_view_112', '2'),
(50, 0, 'megamenu_bottom_block_112', '0'),
(51, 0, 'mg_botban_cont_0_112_link', ''),
(52, 0, 'mg_botban_cont_1_112_link', ''),
(53, 0, 'badge_type_110', '1'),
(54, 0, 'subcat_imgstatus_110', '0'),
(55, 0, 'megamenu_btype_110', '1'),
(56, 0, 'megamenu_btype_view_110', '2'),
(57, 0, 'megamenu_bottom_block_110', '1'),
(58, 0, 'mg_botban_cont_0_110_link', '#'),
(59, 0, 'mg_botban_cont_1_110_link', '#'),
(60, 0, 'badge_type_141', '2'),
(61, 0, 'subcat_imgstatus_141', '1'),
(62, 0, 'megamenu_btype_141', '1'),
(63, 0, 'megamenu_btype_view_141', '1'),
(64, 0, 'megamenu_bottom_block_141', '1'),
(65, 0, 'mg_botban_cont_0_141_link', '#'),
(66, 0, 'mg_botban_cont_1_141_link', '#'),
(72, 0, 'menu_type_114', '2'),
(73, 0, 'menu_type_111', '1'),
(74, 0, 'menu_type_112', '1'),
(75, 0, 'menu_type_110', '2'),
(76, 0, 'menu_type_141', '1'),
(77, 0, 'mg_botban_cont_0_110_img', 'banner-megamenu-01_1501926699.jpg'),
(78, 0, 'mg_botban_cont_1_110_img', 'banner-megamenu-02_1501926699.jpg'),
(79, 0, 'mg_botban_cont_0_141_img', 'banner-megamenu-01_1501927131.jpg'),
(80, 0, 'mg_botban_cont_1_141_img', 'banner-megamenu-02_1501927131.jpg'),
(81, 0, 'breadcrumb_style', '1'),
(82, 0, 'breadcrumb_banner_image', 'breadcrumb_banner_1501934742.jpg'),
(83, 0, 'cat_page_layout', '2columns-left'),
(84, 0, 'catgrid_col_md', '3'),
(85, 0, 'catgrid_col_sm', '3'),
(86, 0, 'catgrid_col_xs', '2'),
(87, 0, 'catgrid_col_xxs', '1'),
(88, 0, 'cat_page_style', '1'),
(89, 0, 'prodlist_page_layout', '2columns-left'),
(90, 0, 'prodgrid_col_md', '3'),
(91, 0, 'prodgrid_col_sm', '3'),
(92, 0, 'prodgrid_col_xs', '2'),
(93, 0, 'prodgrid_col_xxs', '1'),
(94, 0, 'prod_list_addtionalimg_style', '2'),
(95, 0, 'prod_list_nums_addimgs', '3'),
(96, 0, 'display_prod_list_rattings', '1'),
(97, 0, 'display_prod_list_price', '1'),
(98, 0, 'display_prod_list_quickview', '1'),
(99, 0, 'display_prod_list_wishlist', '1'),
(100, 0, 'display_prod_list_addtocart', '1'),
(101, 0, 'display_prod_list_salelabel', '1'),
(102, 0, 'display_prod_list_newlabel', '1'),
(103, 0, 'homepage_version', 'homepage_v1'),
(104, 0, 'homepage_page_layout', '1column'),
(105, 0, 'prodinfo_page_layout', '1column'),
(106, 0, 'prod_img_layout', '2'),
(107, 0, 'prod_tab_style', '2'),
(108, 0, 'display_prod_short_desc', '1'),
(109, 0, 'minicart_style', 'flyout'),
(110, 0, 'display_prod_list_compare', '1'),
(111, 0, 'display_in_ver_menu_114', '1'),
(112, 0, 'display_in_ver_menu_111', '1'),
(113, 0, 'display_in_ver_menu_112', '1'),
(114, 0, 'display_in_ver_menu_110', '1'),
(115, 0, 'display_in_ver_menu_141', '1'),
(116, 0, 'display_in_hor_menu_114', '0'),
(117, 0, 'display_in_hor_menu_111', '1'),
(118, 0, 'display_in_hor_menu_112', '0'),
(119, 0, 'display_in_hor_menu_110', '1'),
(120, 0, 'display_in_hor_menu_141', '1'),
(121, 0, 'display_bottom_banners', '0'),
(122, 0, 'bottom_banners_style', '1'),
(123, 2, 'middle_banner_caption', '&lt;div class=&quot;full-banner-text&quot;&gt;\r\n	&lt;h4&gt;&lt;a href=&quot;#&quot;&gt;Applique Prom Dress&lt;/a&gt;&lt;/h4&gt;\r\n	&lt;h3&gt;&lt;span&gt;From&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Dresses,&lt;/a&gt;&lt;a href=&quot;#&quot;&gt;Fashion&lt;/a&gt;&lt;/h3&gt;\r\n	&lt;div class=&quot;price&quot;&gt;\r\n		&lt;span class=&quot;old-price&quot;&gt;&lt;del&gt;$230.00&lt;/del&gt;&lt;/span&gt;\r\n		&lt;span class=&quot;new-price&quot;&gt;$210.00&lt;/span&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;timer&quot;&gt;\r\n		&lt;div data-countdown=&quot;2017/12/15&quot;&gt;&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;'),
(124, 3, 'middle_banner_caption', '&lt;div class=&quot;full-banner-text&quot;&gt;\r\n	&lt;h4&gt;&lt;a href=&quot;#&quot;&gt;Applique Prom Dress&lt;/a&gt;&lt;/h4&gt;\r\n	&lt;h3&gt;&lt;span&gt;From&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Dresses,&lt;/a&gt;&lt;a href=&quot;#&quot;&gt;Fashion&lt;/a&gt;&lt;/h3&gt;\r\n	&lt;div class=&quot;price&quot;&gt;\r\n		&lt;span class=&quot;old-price&quot;&gt;&lt;del&gt;$230.00&lt;/del&gt;&lt;/span&gt;\r\n		&lt;span class=&quot;new-price&quot;&gt;$210.00&lt;/span&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;timer&quot;&gt;\r\n		&lt;div data-countdown=&quot;2017/12/15&quot;&gt;&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;'),
(125, 4, 'middle_banner_caption', '&lt;div class=&quot;full-banner-text&quot;&gt;\r\n	&lt;h4&gt;&lt;a href=&quot;#&quot;&gt;Applique Prom Dress&lt;/a&gt;&lt;/h4&gt;\r\n	&lt;h3&gt;&lt;span&gt;From&lt;/span&gt;&lt;a href=&quot;#&quot;&gt;Dresses,&lt;/a&gt;&lt;a href=&quot;#&quot;&gt;Fashion&lt;/a&gt;&lt;/h3&gt;\r\n	&lt;div class=&quot;price&quot;&gt;\r\n		&lt;span class=&quot;old-price&quot;&gt;&lt;del&gt;$230.00&lt;/del&gt;&lt;/span&gt;\r\n		&lt;span class=&quot;new-price&quot;&gt;$210.00&lt;/span&gt;\r\n	&lt;/div&gt;\r\n	&lt;div class=&quot;timer&quot;&gt;\r\n		&lt;div data-countdown=&quot;2017/12/15&quot;&gt;&lt;/div&gt;\r\n	&lt;/div&gt;\r\n&lt;/div&gt;'),
(126, 0, 'display_in_hor_menu_160', '0'),
(127, 0, 'display_in_ver_menu_160', '1'),
(128, 0, 'menu_type_160', '1'),
(129, 0, 'badge_type_160', '0'),
(130, 0, 'subcat_imgstatus_160', '0'),
(131, 0, 'megamenu_btype_160', '0'),
(132, 0, 'megamenu_btype_view_160', '2'),
(133, 0, 'megamenu_bottom_block_160', '0'),
(134, 0, 'mg_botban_cont_0_160_link', ''),
(135, 0, 'mg_botban_cont_1_160_link', ''),
(136, 0, 'display_in_hor_menu_159', '0'),
(137, 0, 'display_in_ver_menu_159', '1'),
(138, 0, 'menu_type_159', '1'),
(139, 0, 'badge_type_159', '0'),
(140, 0, 'subcat_imgstatus_159', '0'),
(141, 0, 'megamenu_btype_159', '0'),
(142, 0, 'megamenu_btype_view_159', '2'),
(143, 0, 'megamenu_bottom_block_159', '0'),
(144, 0, 'mg_botban_cont_0_159_link', ''),
(145, 0, 'mg_botban_cont_1_159_link', ''),
(146, 0, 'display_in_hor_menu_158', '0'),
(147, 0, 'display_in_ver_menu_158', '1'),
(148, 0, 'menu_type_158', '1'),
(149, 0, 'badge_type_158', '0'),
(150, 0, 'subcat_imgstatus_158', '0'),
(151, 0, 'megamenu_btype_158', '0'),
(152, 0, 'megamenu_btype_view_158', '2'),
(153, 0, 'megamenu_bottom_block_158', '0'),
(154, 0, 'mg_botban_cont_0_158_link', ''),
(155, 0, 'mg_botban_cont_1_158_link', ''),
(156, 0, 'prod_list_imghover_style', '1'),
(157, 0, 'general_page_layout', '2columns-left'),
(158, 0, 'prod_slider_imghover_style', '1'),
(159, 0, 'theme_color', '#000'),
(160, 0, 'general_font_family', 'Lato'),
(161, 0, 'heading_font_family', 'Montserrat'),
(162, 0, 'font_latin_charset_extended', '0'),
(163, 0, 'font_custom_charset', ''),
(164, 0, 'prodgrid_col_lg', '3'),
(165, 0, 'catgrid_col_lg', '4'),
(166, 0, 'catslide_col_lg', '4'),
(167, 0, 'catslide_col_md', '3'),
(168, 0, 'catslide_col_sm', '3'),
(169, 0, 'catslide_col_xs', '2'),
(170, 0, 'catslide_col_xxs', '1'),
(171, 0, 'prodinfo_col_lg', '4'),
(172, 0, 'prodinfo_col_md', '4'),
(173, 0, 'prodinfo_col_sm', '3'),
(174, 0, 'prodinfo_col_xs', '2'),
(175, 0, 'prodinfo_col_xxs', '2'),
(176, 0, 'google_map', '&lt;iframe src=&quot;https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Auburn+Grove,+Hawthorn,+Victoria,+Australia&amp;aq=0&amp;oq=Auburn+Groove,+Hawthorn&amp;sll=23.223279,72.657137&amp;sspn=0.07651,0.169086&amp;ie=UTF8&amp;hq=&amp;hnear=Auburn+Grove,+Hawthorn+East+Victoria+3123,+Australia&amp;t=m&amp;z=14&amp;ll=-37.825499,145.04689&amp;output=embed&quot;&gt;&lt;br /&gt;&lt;small&gt;&lt;a href=&quot;https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Auburn+Grove,+Hawthorn,+Victoria,+Australia&amp;aq=0&amp;oq=Auburn+Groove,+Hawthorn&amp;sll=23.223279,72.657137&amp;sspn=0.07651,0.169086&amp;ie=UTF8&amp;hq=&amp;hnear=Auburn+Grove,+Hawthorn+East+Victoria+3123,+Australia&amp;t=m&amp;z=14&amp;ll=-37.825499,145.04689&quot; style=&quot;color:#0000FF;text-align:left&quot;&gt;View Larger Map&lt;/a&gt;&lt;/small&gt;&lt;/iframe&gt;'),
(177, 0, 'google_site_key', ''),
(178, 0, 'google_secret_key', ''),
(179, 0, 'prodinfo_image_effects', '2');


CREATE TABLE IF NOT EXISTS pzen_alto_topbanner (
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);

INSERT INTO pzen_alto_topbanner (id, item_type, sort_order, item_image, item_desc, item_link, created_at, updated_at, item_status) VALUES
(1, 2, 1, 'tp1_1501820775.jpg', 'YTo0OntpOjE7czozNDM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtBY2Nlc3NvcmllcyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7bWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzEmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjM0MzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0FjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDttYW4mbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MSZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MzQzOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7QWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNDM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtBY2Nlc3NvcmllcyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7bWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzEmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1'),
(2, 2, 2, 'tb2_1501821270.jpg', 'YTo0OntpOjE7czozNjM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0NvbGxlY3Rpb24mbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1N1bW1lciZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MiZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzYzOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb2xsZWN0aW9uJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdW1tZXImbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciBuLTImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzImbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjM2MzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Q29sbGVjdGlvbiZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3VtbWVyJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNjM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0NvbGxlY3Rpb24mbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1N1bW1lciZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MiZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1'),
(3, 2, 3, 'tp3_1501821354.jpg', 'YTo0OntpOjE7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0pld2VscnkmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1dvbWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0zJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDszJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0pld2VscnkmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1dvbWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0zJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDszJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0pld2VscnkmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1dvbWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0zJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDszJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0pld2VscnkmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1dvbWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0zJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDszJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1'),
(4, 2, 4, 'tp4_1501821386.jpg', 'YTo0OntpOjE7czozNTc6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMyZxdW90OyZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTcHJpbmcmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OzIwMTcmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tNCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzU3OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjMmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3ByaW5nJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDsyMDE3Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciBuLTQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzQmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjM1NzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24zJnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwcmluZyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7MjAxNyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi00JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDs0Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNTc6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMyZxdW90OyZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTcHJpbmcmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OzIwMTcmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tNCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1'),
(5, 2, 5, 'btt1_1504947037.jpg', 'YTo0OntpOjE7czoxNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uIGJjLXN0eWxlMyZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7QXBwbGUgJmx0O3NwYW4mZ3Q7V2F0Y2gmbHQ7L3NwYW4mZ3Q7Jmx0Oy9oNCZndDsNCgkmbHQ7aDMmZ3Q7VEhFIE5FVyZsdDsvaDMmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjE2OToiJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24gYmMtc3R5bGUzJnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtBcHBsZSAmbHQ7c3BhbiZndDtXYXRjaCZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtoMyZndDtUSEUgTkVXJmx0Oy9oMyZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MTY5OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbiBiYy1zdHlsZTMmcXVvdDsmZ3Q7DQoJJmx0O2g0Jmd0O0FwcGxlICZsdDtzcGFuJmd0O1dhdGNoJmx0Oy9zcGFuJmd0OyZsdDsvaDQmZ3Q7DQoJJmx0O2gzJmd0O1RIRSBORVcmbHQ7L2gzJmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uIGJjLXN0eWxlMyZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7QXBwbGUgJmx0O3NwYW4mZ3Q7V2F0Y2gmbHQ7L3NwYW4mZ3Q7Jmx0Oy9oNCZndDsNCgkmbHQ7aDMmZ3Q7VEhFIE5FVyZsdDsvaDMmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(6, 2, 6, 'btt2_1504947096.jpg', 'YTo0OntpOjE7czoxNjQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgYmMtc3R5bGUzJnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtTYWxlICZsdDtzcGFuJmd0OzI1JSZsdDsvc3BhbiZndDsgT2ZmJmx0Oy9oNCZndDsNCgkmbHQ7aDMmZ3Q7Rm9yIFRoaXMgV2VlayEmbHQ7L2gzJmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoxNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uIGJjLXN0eWxlMyZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7QXBwbGUgJmx0O3NwYW4mZ3Q7V2F0Y2gmbHQ7L3NwYW4mZ3Q7Jmx0Oy9oNCZndDsNCgkmbHQ7aDMmZ3Q7VEhFIE5FVyZsdDsvaDMmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE2OToiJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24gYmMtc3R5bGUzJnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtBcHBsZSAmbHQ7c3BhbiZndDtXYXRjaCZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtoMyZndDtUSEUgTkVXJmx0Oy9oMyZndDsNCiZsdDsvZGl2Jmd0OyI7aTo0O3M6MTY5OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbiBiYy1zdHlsZTMmcXVvdDsmZ3Q7DQoJJmx0O2g0Jmd0O0FwcGxlICZsdDtzcGFuJmd0O1dhdGNoJmx0Oy9zcGFuJmd0OyZsdDsvaDQmZ3Q7DQoJJmx0O2gzJmd0O1RIRSBORVcmbHQ7L2gzJmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(7, 2, 7, 'bt1_1504959829.jpg', 'YTo0OntpOjE7czozNDU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb2xsZWN0aW9uJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdW1tZXImbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MSZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzQ1OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gzLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Q29sbGVjdGlvbiZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3VtbWVyJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzEmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjM0NToiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMy1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0NvbGxlY3Rpb24mbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1N1bW1lciZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNDU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb2xsZWN0aW9uJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdW1tZXImbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MSZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(8, 2, 8, 'bt2_1504959919.jpg', 'YTo0OntpOjE7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0FjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtSYWRpbyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0FjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtSYWRpbyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0FjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtSYWRpbyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNTk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDMtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0FjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtSYWRpbyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(9, 2, 9, 'bt1_1505051855.jpg', 'YTo0OntpOjE7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtOZXcgU2VyaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtQb3dlciBUb29scyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtOZXcgU2VyaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtQb3dlciBUb29scyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtOZXcgU2VyaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtQb3dlciBUb29scyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtOZXcgU2VyaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtQb3dlciBUb29scyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(10, 2, 10, 'bt2_1505056549.jpg', 'YTo0OntpOjE7czozMjc6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuIGNsYXNzPSZxdW90O2NvbG9yJnF1b3Q7Jmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTcGVjaWFsIFNhbGUmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuJmd0OzI1JSZsdDsvc3BhbiZndDtPRkYmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzI3OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g1LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24xJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiBjbGFzcz0mcXVvdDtjb2xvciZxdW90OyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3BlY2lhbCBTYWxlJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDsmbHQ7c3BhbiZndDsyNSUmbHQ7L3NwYW4mZ3Q7T0ZGJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjMyNzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4gY2xhc3M9JnF1b3Q7Y29sb3ImcXVvdDsmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwZWNpYWwgU2FsZSZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Jmx0O3NwYW4mZ3Q7MjUlJmx0Oy9zcGFuJmd0O09GRiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozMjc6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuIGNsYXNzPSZxdW90O2NvbG9yJnF1b3Q7Jmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTcGVjaWFsIFNhbGUmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuJmd0OzI1JSZsdDsvc3BhbiZndDtPRkYmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(11, 2, 11, 'bt3_1505056567.jpg', 'YTo0OntpOjE7czoyOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7UG93ZXIgVG9vbHMmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZhbXA7YW1wOyBBY2Nlc3NvcmllcyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjI5MjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMiZxdW90OyZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtQb3dlciBUb29scyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7JmFtcDthbXA7IEFjY2Vzc29yaWVzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MjkyOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g1LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24yJnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1Bvd2VyIFRvb2xzJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDsmYW1wO2FtcDsgQWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDUtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7UG93ZXIgVG9vbHMmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZhbXA7YW1wOyBBY2Nlc3NvcmllcyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(12, 2, 12, 'bt1_1505061122.jpg', 'YTo0OntpOjE7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Rm9yIFdvbWVuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMZWUgUHJvZHVjdHMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Rm9yIFdvbWVuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMZWUgUHJvZHVjdHMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Rm9yIFdvbWVuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMZWUgUHJvZHVjdHMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyNjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Rm9yIFdvbWVuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMZWUgUHJvZHVjdHMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(13, 2, 13, 'bt2_1505061189.jpg', 'YTo0OntpOjE7czozMjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwZWNpYWwgc2FsZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuIGNsYXNzPSZxdW90O3NpemUmcXVvdDsmZ3Q7MjUlJmx0Oy9zcGFuJmd0O09mZiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czozMjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwZWNpYWwgc2FsZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuIGNsYXNzPSZxdW90O3NpemUmcXVvdDsmZ3Q7MjUlJmx0Oy9zcGFuJmd0O09mZiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czozMjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwZWNpYWwgc2FsZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuIGNsYXNzPSZxdW90O3NpemUmcXVvdDsmZ3Q7MjUlJmx0Oy9zcGFuJmd0O09mZiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozMjY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NwZWNpYWwgc2FsZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0OyZsdDtzcGFuIGNsYXNzPSZxdW90O3NpemUmcXVvdDsmZ3Q7MjUlJmx0Oy9zcGFuJmd0O09mZiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(14, 2, 14, 'bt3_1505061205.jpg', 'YTo0OntpOjE7czoyNzY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O05ldyBXZWJpbmFyJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb21taW5nJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7ZGl2Jmd0OyI7aToyO3M6Mjc2OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g2LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtOZXcgV2ViaW5hciZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Q29tbWluZyZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0O2RpdiZndDsiO2k6MztzOjI3NjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNi1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24xJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TmV3IFdlYmluYXImbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0NvbW1pbmcmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDtkaXYmZ3Q7IjtpOjQ7czoyNzY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDYtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O05ldyBXZWJpbmFyJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb21taW5nJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7ZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(15, 2, 15, 'bt1_1505110125.jpg', 'YTo0OntpOjE7czowOiIiO2k6MjtzOjA6IiI7aTozO3M6MDoiIjtpOjQ7czowOiIiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(16, 2, 16, 'bt2_1505110137.jpg', 'YTo0OntpOjE7czowOiIiO2k6MjtzOjA6IiI7aTozO3M6MDoiIjtpOjQ7czowOiIiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(17, 2, 17, 'bt3_1505110148.jpg', 'YTo0OntpOjE7czowOiIiO2k6MjtzOjA6IiI7aTozO3M6MDoiIjtpOjQ7czowOiIiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(18, 2, 18, 'tb1_1505118983.jpg', 'YTo0OntpOjE7czoxODY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Q29zbWV0aWNzJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MTg2OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxMC1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O2gzJmd0O0Nvc21ldGljcyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzQgaXRlbXMmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE4NjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMTAtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtDb3NtZXRpY3MmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDs0IGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxODY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Q29zbWV0aWNzJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(19, 2, 19, 'tb2_1505118998.jpg', 'YTo0OntpOjE7czoxODY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Q29zbWV0aWNzJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MTg2OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxMC1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O2gzJmd0O0Nvc21ldGljcyZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzQgaXRlbXMmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE4NjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMTAtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtDb3NtZXRpY3MmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDs0IGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxODY6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Q29zbWV0aWNzJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7NCBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(20, 2, 20, 'tb3_1505119017.jpg', 'YTo0OntpOjE7czoxODU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7RmFzaGlvbiZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzExIGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoxODU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7RmFzaGlvbiZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzExIGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoxODU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7RmFzaGlvbiZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzExIGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxODU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7RmFzaGlvbiZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzExIGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(21, 2, 21, 'tb4_1505119031.jpg', 'YTo0OntpOjE7czoxODM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Rmxvd2VyJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7MyBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MTgzOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxMC1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O2gzJmd0O0Zsb3dlciZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0OzMgaXRlbXMmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE4MzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMTAtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtGbG93ZXImbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDszIGl0ZW1zJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxODM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDEwLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Rmxvd2VyJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7MyBpdGVtcyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(22, 2, 22, 'tb1_1505123222.jpg', 'YTo0OntpOjE7czozNDQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7QWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czozNDQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7QWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czozNDQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7QWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNDQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7QWNjZXNzb3JpZXMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsxJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(23, 2, 23, 'tb2_1505123756.jpg', 'YTo0OntpOjE7czozNjQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb2xsZWN0aW9uJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdW1tZXImbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciBuLTImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzImbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjM2NDoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMTEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0NvbGxlY3Rpb24mbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1N1bW1lciZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MiZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MzY0OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxMS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7Q29sbGVjdGlvbiZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3VtbWVyJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi0yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNjQ6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtDb2xsZWN0aW9uJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdW1tZXImbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciBuLTImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzImbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(24, 2, 24, 'tb3_1505123777.jpg', 'YTo0OntpOjE7czozNjA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjMmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtKZXdlbHJ5Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtXb21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tNCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzYwOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2gxMS1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24zJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7SmV3ZWxyeSZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7V29tYW4mbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O251bWJlciBuLTQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OzMmbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjM2MDoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoMTEtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uMyZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0pld2VscnkmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1dvbWFuJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtudW1iZXIgbi00JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDszJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozNjA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDExLWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbjMmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtKZXdlbHJ5Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtXb21hbiZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7bnVtYmVyIG4tNCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7MyZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0');


CREATE TABLE IF NOT EXISTS pzen_alto_bottombanner (
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);


INSERT INTO pzen_alto_bottombanner (id, item_type, sort_order, item_image, item_desc, item_link, created_at, updated_at, item_status) VALUES
(1, 2, 1, 'b1_1501825792.jpg', 'YTo0OntpOjE7czoyNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TmV3IGxhbXAmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0xpdmluZyBSb29tIExhbXAmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoyNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TmV3IGxhbXAmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0xpdmluZyBSb29tIExhbXAmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoyNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TmV3IGxhbXAmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0xpdmluZyBSb29tIExhbXAmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyNjk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TmV3IGxhbXAmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0xpdmluZyBSb29tIExhbXAmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(2, 2, 2, 'b2_1501825827.jpg', 'YTo0OntpOjE7czoyOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMaXZpbmcgUm9vbSBGdXJuaXR1cmUmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1VwaG9sc3RlcmVkJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjI5MjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNC1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMSZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O0xpdmluZyBSb29tIEZ1cm5pdHVyZSZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7VXBob2xzdGVyZWQmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MjkyOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g0LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24xJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7TGl2aW5nIFJvb20gRnVybml0dXJlJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtVcGhvbHN0ZXJlZCZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtMaXZpbmcgUm9vbSBGdXJuaXR1cmUmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1VwaG9sc3RlcmVkJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(3, 2, 3, 'b3_1501825867.jpg', 'YTo0OntpOjE7czoyNzU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtUaGUgTmV3Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtCb29rY2FzZSZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoyNzU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtUaGUgTmV3Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtCb29rY2FzZSZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoyNzU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtUaGUgTmV3Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtCb29rY2FzZSZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyNzU6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtUaGUgTmV3Jmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtCb29rY2FzZSZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(4, 2, 4, 'bb4_1501825912.jpg', 'YTo0OntpOjE7czozMDM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTaWx2ZXIgTmFpbGhlYWRzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzIGNsYXNzPSZxdW90O3BhZCZxdW90OyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3Rvb2wmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MzAzOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g0LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U2lsdmVyIE5haWxoZWFkcyZsdDsvYSZndDsmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyBjbGFzcz0mcXVvdDtwYWQmcXVvdDsmZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1N0b29sJmx0Oy9hJmd0OyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjMwMzoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNC1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Jmx0O2EgaHJlZj0mcXVvdDsjJnF1b3Q7Jmd0O1NpbHZlciBOYWlsaGVhZHMmbHQ7L2EmZ3Q7Jmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMgY2xhc3M9JnF1b3Q7cGFkJnF1b3Q7Jmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTdG9vbCZsdDsvYSZndDsmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czozMDM6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDQtYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0OyZsdDthIGhyZWY9JnF1b3Q7IyZxdW90OyZndDtTaWx2ZXIgTmFpbGhlYWRzJmx0Oy9hJmd0OyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzIGNsYXNzPSZxdW90O3BhZCZxdW90OyZndDsmbHQ7YSBocmVmPSZxdW90OyMmcXVvdDsmZ3Q7U3Rvb2wmbHQ7L2EmZ3Q7Jmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(5, 2, 5, 'bb1_1504944046.jpg', 'YTo0OntpOjE7czoyMDg6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uIGJjLXN0eWxlMiZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7QXBwbGUgJmx0O3NwYW4mZ3Q7Q29sbGVjdGlvbiZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtoMyZndDtTQUxFIE9GRiAmbHQ7c3BhbiZndDsyNSUmbHQ7L3NwYW4mZ3Q7IE5PVyZsdDsvaDMmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MjtzOjIwODoiJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0b24gYmMtc3R5bGUyJnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtBcHBsZSAmbHQ7c3BhbiZndDtDb2xsZWN0aW9uJmx0Oy9zcGFuJmd0OyZsdDsvaDQmZ3Q7DQoJJmx0O2gzJmd0O1NBTEUgT0ZGICZsdDtzcGFuJmd0OzI1JSZsdDsvc3BhbiZndDsgTk9XJmx0Oy9oMyZndDsNCiZsdDsvZGl2Jmd0OyI7aTozO3M6MjA4OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRvbiBiYy1zdHlsZTImcXVvdDsmZ3Q7DQoJJmx0O2g0Jmd0O0FwcGxlICZsdDtzcGFuJmd0O0NvbGxlY3Rpb24mbHQ7L3NwYW4mZ3Q7Jmx0Oy9oNCZndDsNCgkmbHQ7aDMmZ3Q7U0FMRSBPRkYgJmx0O3NwYW4mZ3Q7MjUlJmx0Oy9zcGFuJmd0OyBOT1cmbHQ7L2gzJmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyMDg6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdG9uIGJjLXN0eWxlMiZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7QXBwbGUgJmx0O3NwYW4mZ3Q7Q29sbGVjdGlvbiZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtoMyZndDtTQUxFIE9GRiAmbHQ7c3BhbiZndDsyNSUmbHQ7L3NwYW4mZ3Q7IE5PVyZsdDsvaDMmZ3Q7DQombHQ7L2RpdiZndDsiO30=', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(6, 2, 6, 'bb2_1504944331.jpg', 'YTo0OntpOjE7czoxOTg6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgYmMtc3R5bGU0JnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtOZXcgQXBwbGUgJmx0O3NwYW4mZ3Q7SW1hYyZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtwJmd0O1JFVElOQS4gTk9XIElOIENPTE9TU0FMICZsdDticiZndDtBTkQgR0lOT1JNT1VTLiZsdDsvcCZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MTk4OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IGJjLXN0eWxlNCZxdW90OyZndDsNCgkmbHQ7aDQmZ3Q7TmV3IEFwcGxlICZsdDtzcGFuJmd0O0ltYWMmbHQ7L3NwYW4mZ3Q7Jmx0Oy9oNCZndDsNCgkmbHQ7cCZndDtSRVRJTkEuIE5PVyBJTiBDT0xPU1NBTCAmbHQ7YnImZ3Q7QU5EIEdJTk9STU9VUy4mbHQ7L3AmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE5ODoiJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCBiYy1zdHlsZTQmcXVvdDsmZ3Q7DQoJJmx0O2g0Jmd0O05ldyBBcHBsZSAmbHQ7c3BhbiZndDtJbWFjJmx0Oy9zcGFuJmd0OyZsdDsvaDQmZ3Q7DQoJJmx0O3AmZ3Q7UkVUSU5BLiBOT1cgSU4gQ09MT1NTQUwgJmx0O2JyJmd0O0FORCBHSU5PUk1PVVMuJmx0Oy9wJmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxOTg6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgYmMtc3R5bGU0JnF1b3Q7Jmd0Ow0KCSZsdDtoNCZndDtOZXcgQXBwbGUgJmx0O3NwYW4mZ3Q7SW1hYyZsdDsvc3BhbiZndDsmbHQ7L2g0Jmd0Ow0KCSZsdDtwJmd0O1JFVElOQS4gTk9XIElOIENPTE9TU0FMICZsdDticiZndDtBTkQgR0lOT1JNT1VTLiZsdDsvcCZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(7, 2, 7, 'bb1_1505065637.jpg', 'YTo0OntpOjE7czoxOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0O0Zsb3dlciBDb2xsZWN0aW9uJmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7U3ByaW5nJmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MTkyOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g3LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0JnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDtGbG93ZXIgQ29sbGVjdGlvbiZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0O1NwcmluZyZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjE5MjoiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNy1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7Rmxvd2VyIENvbGxlY3Rpb24mbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDtTcHJpbmcmbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoxOTI6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQmcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0O0Zsb3dlciBDb2xsZWN0aW9uJmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7U3ByaW5nJmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(8, 2, 8, 'bb2_1505065659.jpg', 'YTo0OntpOjE7czoyNDk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7c3BhbiBjbGFzcz0mcXVvdDtzaXplJnF1b3Q7Jmd0OzIwJSZsdDsvc3BhbiZndDsgT2ZmJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7TmV3IEZsb3dlciZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MjQ5OiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g3LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24xJnF1b3Q7Jmd0Ow0KCQkmbHQ7aDMmZ3Q7Jmx0O3NwYW4gY2xhc3M9JnF1b3Q7c2l6ZSZxdW90OyZndDsyMCUmbHQ7L3NwYW4mZ3Q7IE9mZiZsdDsvaDMmZ3Q7DQoJCSZsdDtzcGFuJmd0O05ldyBGbG93ZXImbHQ7L3NwYW4mZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjI0OToiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNy1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMSZxdW90OyZndDsNCgkJJmx0O2gzJmd0OyZsdDtzcGFuIGNsYXNzPSZxdW90O3NpemUmcXVvdDsmZ3Q7MjAlJmx0Oy9zcGFuJmd0OyBPZmYmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDtOZXcgRmxvd2VyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyNDk6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDsmbHQ7c3BhbiBjbGFzcz0mcXVvdDtzaXplJnF1b3Q7Jmd0OzIwJSZsdDsvc3BhbiZndDsgT2ZmJmx0Oy9oMyZndDsNCgkJJmx0O3NwYW4mZ3Q7TmV3IEZsb3dlciZsdDsvc3BhbiZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(9, 2, 9, 'bb3_1505065677.jpg', 'YTo0OntpOjE7czoyMDE6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0O0FjY2Vzc29yaWVzJmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7U3VtbWVyJmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7aToyO3M6MjAxOiImbHQ7ZGl2IGNsYXNzPSZxdW90O2g3LWJjLXN0eWxlMSZxdW90OyZndDsNCgkmbHQ7ZGl2IGNsYXNzPSZxdW90O2Jhbm5lci10ZXh0IHRleHQtcG9zaXRpb24yJnF1b3Q7Jmd0Ow0KCQkmbHQ7c3BhbiZndDtBY2Nlc3NvcmllcyZsdDsvc3BhbiZndDsNCgkJJmx0O2gzJmd0O1N1bW1lciZsdDsvaDMmZ3Q7DQoJJmx0Oy9kaXYmZ3Q7DQombHQ7L2RpdiZndDsiO2k6MztzOjIwMToiJmx0O2RpdiBjbGFzcz0mcXVvdDtoNy1iYy1zdHlsZTEmcXVvdDsmZ3Q7DQoJJmx0O2RpdiBjbGFzcz0mcXVvdDtiYW5uZXItdGV4dCB0ZXh0LXBvc2l0aW9uMiZxdW90OyZndDsNCgkJJmx0O3NwYW4mZ3Q7QWNjZXNzb3JpZXMmbHQ7L3NwYW4mZ3Q7DQoJCSZsdDtoMyZndDtTdW1tZXImbHQ7L2gzJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyMDE6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjImcXVvdDsmZ3Q7DQoJCSZsdDtzcGFuJmd0O0FjY2Vzc29yaWVzJmx0Oy9zcGFuJmd0Ow0KCQkmbHQ7aDMmZ3Q7U3VtbWVyJmx0Oy9oMyZndDsNCgkmbHQ7L2RpdiZndDsNCiZsdDsvZGl2Jmd0OyI7fQ==', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0'),
(10, 2, 10, 'bb4_1505065692.jpg', 'YTo0OntpOjE7czoyMDA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtSZWQgUm9zZXMmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDtGb3IgaGVyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjI7czoyMDA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtSZWQgUm9zZXMmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDtGb3IgaGVyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjM7czoyMDA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtSZWQgUm9zZXMmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDtGb3IgaGVyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7IjtpOjQ7czoyMDA6IiZsdDtkaXYgY2xhc3M9JnF1b3Q7aDctYmMtc3R5bGUxJnF1b3Q7Jmd0Ow0KCSZsdDtkaXYgY2xhc3M9JnF1b3Q7YmFubmVyLXRleHQgdGV4dC1wb3NpdGlvbjEmcXVvdDsmZ3Q7DQoJCSZsdDtoMyZndDtSZWQgUm9zZXMmbHQ7L2gzJmd0Ow0KCQkmbHQ7c3BhbiZndDtGb3IgaGVyJmx0Oy9zcGFuJmd0Ow0KCSZsdDsvZGl2Jmd0Ow0KJmx0Oy9kaXYmZ3Q7Ijt9', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '0');



CREATE TABLE IF NOT EXISTS pzen_alto_sidebarbanner(
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);

INSERT INTO pzen_alto_sidebarbanner (id, item_type, sort_order, item_image, item_desc, item_link, created_at, updated_at, item_status) VALUES
(1, 2, 1, 'sb1_1505019313.jpg', '', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1'),
(2, 2, 2, 'sb2_1505019323.jpg', '', '#', '0001-01-01 00:00:00', '0001-01-01 00:00:00', '1');



UPDATE template_select set template_dir='alto';

INSERT INTO layout_boxes (layout_template, layout_box_name, layout_box_status, layout_box_location, layout_box_sort_order, layout_box_sort_order_single, layout_box_status_single ) VALUES
('alto', 'tpl_pzen_categories.php', 1, 1, 0, 0, 0),
('alto', 'tpl_pzen_sidebar_megamenu.php', 1, 1, 0, 0, 0),
('alto', 'best_sellers.php', 1, 1, 1, 0, 0),
('alto', 'news_box_sidebox.php', 1, 1, 2, 0, 0),
('alto', 'whats_new.php', 1, 1, 5, 0, 0),
('alto', 'featured.php', 1, 1, 6, 0, 0),
('alto', 'testimonials_manager.php', 1, 1, 7, 0, 0),
('alto', 'reviews.php', 1, 0, 0, 0, 0),
('alto', 'specials.php', 1, 0, 1, 0, 0),
('alto', 'search.php', 1, 0, 2, 0, 0),
('alto', 'wishlist.php', 1, 0, 3, 0, 0),
('alto', 'manufacturers.php', 1, 0, 4, 0, 0),
('alto', 'currencies.php', 1, 0, 5, 0, 0),
('alto', 'dynamic_price_updater_sidebox.php', 1, 0, 6, 0, 0),
('alto', 'ezpages_drop_menu.php', 1, 0, 7, 0, 0),
('alto', 'dynamic_filter.php', 1, 1, 0, 0, 0);

UPDATE configuration set configuration_value='false' where configuration_key='SHOW_COUNTS';
UPDATE configuration set configuration_value='12' where configuration_key='MAX_DISPLAY_SPECIAL_PRODUCTS';
UPDATE configuration set configuration_value='8' where configuration_key='MAX_DISPLAY_NEW_PRODUCTS';
UPDATE configuration set configuration_value='8' where configuration_key='MAX_DISPLAY_SPECIAL_PRODUCTS_INDEX';
UPDATE configuration set configuration_value='8' where configuration_key='MAX_DISPLAY_SEARCH_RESULTS_FEATURED';
UPDATE configuration set configuration_value='5' where configuration_key='MAX_DISPLAY_NEW_REVIEWS';
UPDATE configuration set configuration_value='4' where configuration_key='MAX_RANDOM_SELECT_REVIEWS';
UPDATE configuration set configuration_value='4' where configuration_key='MAX_RANDOM_SELECT_NEW';
UPDATE configuration set configuration_value='4' where configuration_key='MAX_RANDOM_SELECT_FEATURED_PRODUCTS';
UPDATE configuration set configuration_value='4' where configuration_key='MAX_RANDOM_SELECT_SPECIALS';
UPDATE configuration set configuration_value='12' where configuration_key='MAX_DISPLAY_PRODUCTS_NEW';
UPDATE configuration set configuration_value='12' where configuration_key='MAX_DISPLAY_RESULTS_CATEGORIES';
UPDATE configuration set configuration_value='12' where configuration_key='MAX_DISPLAY_PRODUCTS_FEATURED_PRODUCTS';
UPDATE configuration set configuration_value='12' where configuration_key='MAX_DISPLAY_PRODUCTS_ALL';
UPDATE configuration set configuration_value='7' where configuration_key='MAX_DISPLAY_BESTSELLERS';
UPDATE configuration set configuration_value='4' where configuration_key='SHOW_PRODUCT_INFO_COLUMNS_FEATURED_PRODUCTS';
UPDATE configuration set configuration_value='4' where configuration_key='SHOW_PRODUCT_INFO_COLUMNS_NEW_PRODUCTS';
UPDATE configuration set configuration_value='4' where configuration_key='SHOW_PRODUCT_INFO_COLUMNS_SPECIALS_PRODUCTS';

UPDATE configuration set configuration_value='112' where configuration_key='SMALL_IMAGE_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='SMALL_IMAGE_HEIGHT';
UPDATE configuration set configuration_value='' where configuration_key='SUBCATEGORY_IMAGE_WIDTH';
UPDATE configuration set configuration_value='' where configuration_key='SUBCATEGORY_IMAGE_HEIGHT';
UPDATE configuration set configuration_value='' where configuration_key='CATEGORY_ICON_IMAGE_WIDTH';
UPDATE configuration set configuration_value='' where configuration_key='CATEGORY_ICON_IMAGE_HEIGHT';
UPDATE configuration set configuration_value='' where configuration_key='IMAGE_SHOPPING_CART_WIDTH';
UPDATE configuration set configuration_value='250' where configuration_key='IMAGE_SHOPPING_CART_HEIGHT';
UPDATE configuration set configuration_value='true' where configuration_key='CONFIG_CALCULATE_IMAGE_SIZE';
UPDATE configuration set configuration_value='' where configuration_key='SUBCATEGORY_IMAGE_TOP_WIDTH';
UPDATE configuration set configuration_value='' where configuration_key='SUBCATEGORY_IMAGE_TOP_HEIGHT';
UPDATE configuration set configuration_value='450' where configuration_key='MEDIUM_IMAGE_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='MEDIUM_IMAGE_HEIGHT';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_PRODUCT_LISTING_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_PRODUCT_LISTING_HEIGHT';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_PRODUCT_NEW_LISTING_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_PRODUCT_NEW_LISTING_HEIGHT';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_PRODUCT_NEW_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_PRODUCT_NEW_HEIGHT';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_FEATURED_PRODUCTS_LISTING_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_FEATURED_PRODUCTS_LISTING_HEIGHT';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_PRODUCT_ALL_LISTING_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_PRODUCT_ALL_LISTING_HEIGHT';
UPDATE configuration set configuration_value='1' where configuration_key='PROPORTIONAL_IMAGES_STATUS';

UPDATE configuration set configuration_value='1' where configuration_key='PRODUCT_LIST_IMAGE';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_LIST_MANUFACTURER';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_LIST_MODEL';
UPDATE configuration set configuration_value='2' where configuration_key='PRODUCT_LIST_NAME';
UPDATE configuration set configuration_value='3' where configuration_key='PRODUCT_LIST_PRICE';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_LIST_QUANTITY';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_LIST_WEIGHT';
UPDATE configuration set configuration_value='2' where configuration_key='PREV_NEXT_BAR_LOCATION';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_LISTING_MULTIPLE_ADD_TO_CART';
UPDATE configuration set configuration_value='' where configuration_key='SHOW_BANNERS_GROUP_SET6';
UPDATE configuration set configuration_value='' where configuration_key='BOX_WIDTH_lEFT';
UPDATE configuration set configuration_value='' where configuration_key='BOX_WIDTH_RIGHT';

UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_NEW_LISTING_MULTIPLE_ADD_TO_CART';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_FEATURED_LISTING_MULTIPLE_ADD_TO_CART';
UPDATE configuration set configuration_value='0' where configuration_key='PRODUCT_ALL_LISTING_MULTIPLE_ADD_TO_CART';

UPDATE configuration set configuration_value='0' where configuration_key='SHOW_PRODUCT_INFO_CATEGORY_BEST_SELLERS';
UPDATE configuration set configuration_value='0' where configuration_key='SHOW_PRODUCT_INFO_CATEGORY_NEW_PRODUCTS';
UPDATE configuration set configuration_value='0' where configuration_key='SHOW_PRODUCT_INFO_CATEGORY_FEATURED_PRODUCTS';
UPDATE configuration set configuration_value='1' where configuration_key='SHOW_PRODUCT_INFO_CATEGORY_SPECIALS_PRODUCTS';

UPDATE configuration set configuration_value='false' where configuration_title='Add period prefix to cookie domain';

UPDATE configuration set configuration_value='yes' where configuration_key='IH_RESIZE';

UPDATE configuration set configuration_value='false' where configuration_key='ACCOUNT_COMPANY';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_GENDER';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_DOB';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_SUBURB';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_STATE';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_STATE_DRAW_INITIAL_DROPDOWN';
UPDATE configuration set configuration_value='true' where configuration_key='ACCOUNT_FAX_NUMBER';

UPDATE configuration set configuration_value='true' where configuration_key='DISPLAY_CONDITIONS_ON_CHECKOUT';
UPDATE configuration set configuration_value='true' where configuration_key='DISPLAY_PRIVACY_CONDITIONS';

UPDATE configuration set configuration_value='6' where configuration_key='SHOW_PRODUCT_INFO_COLUMNS_ALSO_PURCHASED_PRODUCTS';
UPDATE configuration set configuration_value='1' where configuration_key='PRODUCT_INFO_PREVIOUS_NEXT';

UPDATE configuration set configuration_value='' where configuration_key='BREAD_CRUMBS_SEPARATOR';
UPDATE configuration set configuration_value='1' where configuration_key='DEFINE_BREADCRUMB_STATUS';
UPDATE configuration set configuration_value='false' where configuration_key='SHOW_CATEGORIES_BOX_SPECIALS';
UPDATE configuration set configuration_value='false' where configuration_key='SHOW_CATEGORIES_BOX_PRODUCTS_NEW';
UPDATE configuration set configuration_value='false' where configuration_key='SHOW_CATEGORIES_BOX_FEATURED_PRODUCTS';
UPDATE configuration set configuration_value='false' where configuration_key='SHOW_CATEGORIES_BOX_PRODUCTS_ALL';
UPDATE configuration set configuration_value='1' where configuration_key='SHOW_CUSTOMER_GREETING';
UPDATE configuration set configuration_value='&nbsp;-' where configuration_title='Categories Separator between the Category Name and Count' and configuration_key='CATEGORIES_SEPARATOR';
UPDATE configuration set configuration_value='<i class="fa fa-angle-right"></i>' where configuration_title='Categories Separator between the Category Name and Sub Categories';
UPDATE configuration set configuration_value='yes' where configuration_title='CSS Buttons';
UPDATE configuration set configuration_value='True' where configuration_key='USE_SPLIT_LOGIN_MODE';
UPDATE configuration set configuration_value='false' where configuration_key='DISPLAY_CART';

UPDATE configuration set configuration_value='2' where configuration_key='SHOW_SHIPPING_ESTIMATOR_BUTTON';

UPDATE configuration set configuration_value='0' where configuration_key='DEFINE_MAIN_PAGE_STATUS';

UPDATE configuration set configuration_value='3' where configuration_key='SHOW_PRODUCT_INFO_MAIN_BEST_SELLERS';
UPDATE configuration set configuration_value='9' where configuration_key='MAX_DISPLAY_SEARCH_RESULTS_BEST_SELLERS';
UPDATE configuration set configuration_value='263' where configuration_key='IMAGE_BEST_SELLERS_LISTING_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='IMAGE_BEST_SELLERS_LISTING_HEIGHT';

UPDATE configuration set configuration_value='' where configuration_key='USU_FILTER_PAGES';

UPDATE configuration set configuration_value='true' where configuration_key='DPU_STATUS';

UPDATE configuration set configuration_value='4' where configuration_key='NEWS_BOX_SHOW_CENTERBOX';
UPDATE configuration set configuration_value='4' where configuration_key='NEWS_BOX_SHOW_NEWS';
UPDATE configuration set configuration_value='130' where configuration_key='NEWS_BOX_CONTENT_LENGTH_CENTERBOX';

UPDATE configuration set configuration_value='130' where configuration_key='DEFINE_TESTIMONIAL_STATUS';
UPDATE configuration set configuration_value='170' where configuration_key='TESTIMONIAL_IMAGE_HEIGHT';
UPDATE configuration set configuration_value='0' where configuration_key='TESTIMONIAL_IMAGE_WIDTH';
UPDATE configuration set configuration_value='0' where configuration_key='TESTIMONIAL_IMAGE_WIDTH';

UPDATE configuration set configuration_value='0' where configuration_key='SHOW_FOOTER_IP';

delete from configuration where configuration_key in ('PRODUCT_LISTING_LAYOUT_STYLE');
delete from configuration where configuration_key in ('PRODUCT_LISTING_COLUMNS_PER_ROW');
delete from configuration where configuration_key in ('PRODUCT_LISTING_LAYOUT_STYLE_CUSTOMER');
delete from configuration where configuration_key in ('PRODUCT_LISTING_GRID_SORT');

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Product Listing - Layout Style', 'PRODUCT_LISTING_LAYOUT_STYLE', 'columns', 'Select the layout style:&lt;br /&gt;Each product can be listed in its own row (rows option) or products can be listed in multiple columns per row (columns option)&lt;br /&gt; If customer control is enabled this sets the default style.', '8', '41', NULL, now(), NULL, 'zen_cfg_select_option(array(\'rows\', \'columns\'),');

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Product Listing - Columns Per Row', 'PRODUCT_LISTING_COLUMNS_PER_ROW', '3', 'Select the number of columns of products to show in each row in the product listing. The default setting is 3.', '8', '42', NULL, now(), NULL, NULL);

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Product Listing - Layout Style - Customer Control', 'PRODUCT_LISTING_LAYOUT_STYLE_CUSTOMER', '1', 'Allow the customer to select the layout style (0=no, 1=yes):', '8', '43', NULL, now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),');

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Product Listing - Show Sorter for Columns Layout', 'PRODUCT_LISTING_GRID_SORT', '1', 'Allow the customer to select the item sort order (0=no, 1=yes):', '8', '44', NULL, now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),');


INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Show Languages in Header?', 'HEADER_LANGUAGES_DISPLAY', 'True', 'Display the Languages flags/links in Header?', 19, 170, NULL, now(), NULL, 'zen_cfg_select_option(array(\'True\', \'False\'), ');

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Show Currencies in Header?', 'HEADER_CURRENCIES_DISPLAY', 'True', 'Display the Currencies symbols/links in Header?', 19, 171, NULL, now(), NULL, 'zen_cfg_select_option(array(\'True\', \'False\'), ');

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Max Products to Compare', 'COMPARE_VALUE_COUNT', '4', 'The number of products to compare at one time. Set 0 to disable.', '19', '300', now());

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Max Products to Compare', 'COMPARE_DESCRIPTION', '300', 'How many characters max to show of the products description.', '19', '151', now());

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Image - Sidebar Banners Width', 'PZEN_SIDEBAR_BANNER_IMAGE_WIDTH', '291', 'Default = 291', 4, 44, now());
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Image - Sidebar Banners Height', 'PZEN_SIDEBAR_BANNER_IMAGE_HEIGHT', '416', 'Default = 416', 4, 44, now());

#
# Disqus
#

INSERT INTO configuration_group (configuration_group_title,configuration_group_description,sort_order,visible) VALUES ('Disqus Comments', 'Disqus Comments Configuration', '1', '1');
UPDATE configuration_group SET sort_order = last_insert_id() WHERE configuration_group_id = last_insert_id();

SET @t4=0;
SELECT (@t4:=configuration_group_id) as t4 
FROM configuration_group
WHERE configuration_group_title= 'Disqus Comments';

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES 
('Enable Disqus', 'DISQUS_STATUS', 'true', 'Turn On/Off Disqus Comments System', @t4, 1, NOW(), NOW(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
('Site Shortname', 'DISQUS_SHORTNAME', 'perfectus-themes', 'Your Disqus Site Shortname. Sign Up <a href="http://disqus.com/" target="_blank">here</a> if you do not have it yet.', @t4, 2, NOW(), NOW(), NULL, NULL),
('Element ID', 'DISQUS_ELEMENT_ID', 'disqus_thread', 'Disqus HTML Element ID, this the place where disqus appear. Default is "disqus_thread"', @t4, 3, NOW(), NOW(), NULL, NULL);

INSERT INTO admin_pages (page_key, language_key, main_page, page_params, menu_key, display_on_menu, sort_order) VALUES ('configDisqus', 'BOX_CONFIGURATION_DISQUS', 'FILENAME_CONFIGURATION', CONCAT('gID=',@t4), 'configuration', 'Y', 100);

#
# wishlist
#

SELECT @cid:=configuration_group_id
FROM configuration_group
WHERE configuration_group_title= 'Wish list';
DELETE FROM configuration WHERE configuration_group_id = @cid;
DELETE FROM configuration_group WHERE configuration_group_id = @cid;

INSERT INTO configuration_group VALUES (NULL, 'Wish list', 'Settings for Wish list', '1', '1');


SET @cid=last_insert_id();
UPDATE configuration_group SET sort_order = @cid WHERE configuration_group_id = @cid;

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist Module Switch', 'UN_DB_MODULE_WISHLISTS_ENABLED', 'true', 'Set this option true or false to enable or disable the wishlist', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist sidebox header link', 'UN_DB_SIDEBOX_LINK_HEADER', 'true', 'Set this option true or false to make the sidebox header a link to the wishlist page.', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist allow multiple lists', 'UN_DB_ALLOW_MULTIPLE_WISHLISTS', 'true', 'Set this option true or false to allow for more than 1 wishlist', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist display category filter', 'UN_DB_DISPLAY_CATEGORY_FILTER', 'true', 'Set this option true or false to enable a category filter', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist default name', 'DEFAULT_WISHLIST_NAME', 'Default', 'Enter the name you want to be assigned to the initial wishlist.', @cid, NULL, now(), now(), NULL, NULL);
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist show list after product addition', 'DISPLAY_WISHLIST', 'true', 'Set this option true or false to show the wishlist after a product was added to the wishlist', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist display max items in extended view', 'UN_MAX_DISPLAY_EXTENDED', '10', 'Enter the maximum amount of products you want to show in extended view.<br />default = 10', @cid, NULL, now(), now(), NULL, NULL);
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist display max items in compact view', 'UN_MAX_DISPLAY_COMPACT', '20', 'Enter the maximum amount of products you want to show in extended view.<br />default = 20', @cid, NULL, now(), now(), NULL, NULL);
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist default view Switch', 'UN_DEFAULT_LIST_VIEW', 'extended', 'Set the default view of the list to compact or extended view', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'compact\', \'extended\'),');
INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES ('Wishlist allow multiple products to cart', 'UN_DB_ALLOW_MULTIPLE_PRODUCTS_CART_COMPACT', 'false', 'Set this option true or false to allow multiple products to be moved in the cart via checkboxes in compact view', @cid, NULL, now(), now(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),');

DELETE FROM admin_pages WHERE page_key='configWishlist';
INSERT INTO admin_pages (page_key,language_key,main_page,page_params,menu_key,display_on_menu,sort_order) VALUES ('configWishlist','BOX_CONFIGURATION_WISH_LIST','FILENAME_CONFIGURATION',CONCAT('gID=',@cid), 'configuration', 'Y', @cid);


DROP TABLE IF EXISTS un_wishlists;
CREATE TABLE IF NOT EXISTS un_wishlists (
  id int(11) NOT NULL auto_increment,
  customers_id int(11) NOT NULL default '0',
  created datetime NOT NULL default '0001-01-01 00:00:00',
  modified datetime NOT NULL default '0001-01-01 00:00:00',
  name varchar(255) default NULL,
  comment varchar(255) default NULL,
  default_status tinyint(1) NOT NULL default '0',
  public_status tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (id)
);
INSERT INTO un_wishlists VALUES (1, 0, now(), now(), 'donotuse', 'donotuse', 0, 0);


DROP TABLE IF EXISTS un_products_to_wishlists;
CREATE TABLE IF NOT EXISTS un_products_to_wishlists (
  products_id int(11) NOT NULL default '0',
  un_wishlists_id int(11) NOT NULL default '0',
  created datetime NOT NULL default '0001-01-01 00:00:00',
  modified datetime NOT NULL default '0001-01-01 00:00:00',
  quantity int(2) NOT NULL default '1',
  priority int(1) NOT NULL default '2',
  comment varchar(255) default NULL,
  attributes varchar(255) default NULL,
  PRIMARY KEY  (products_id,un_wishlists_id)
);

#
# manufacturers
#

DELETE FROM configuration_group WHERE configuration_group_title LIKE 'Manufacturers All Config' LIMIT 2;
DELETE FROM configuration WHERE configuration_description LIKE 'Manufacturers All Listing:%' LIMIT 7;

INSERT INTO configuration_group (configuration_group_title ,configuration_group_description ,sort_order ,visible) VALUES ('Manufacturers All Config', 'Manufacturers All Config', '1', '1');

SELECT @gida:=configuration_group_id
FROM configuration_group
WHERE configuration_group_title= 'Layout Settings'
LIMIT 1;

SELECT @gid:=configuration_group_id
FROM configuration_group
WHERE configuration_group_title= 'Manufacturers All Config'
LIMIT 1;

UPDATE configuration_group SET sort_order = @gid WHERE configuration_group_id = @gid;

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) VALUES 
('Categories Box - Show Manufacturers All Link', 'SHOW_CATEGORIES_BOX_MANUFACTURERS_ALL', '1', 'Manufacturers All Listing: Set this to 1 if you want to show the All Manufacturers link to show in the Categories Box.', @gida, '0', now(), now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),'),
('Display Empty Manufacturers', 'MANUFACTURERS_ALL_EMPTY_SHOW', '0', 'Manufacturers All Listing: Set this to 1 if you want manufacturers with no products to show on the list.', @gid, '7', now(), now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),'),
('Display Manufacturer Image', 'MANUFACTURERS_ALL_IMAGE_SHOW', '1', 'Manufacturers All Listing: Set this to 1 if you want the manufacturers logo to appear with the listing.', @gid, '7', now(), now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),'),
('Display Manufacturer URL', 'MANUFACTURERS_ALL_URL_SHOW', '0', 'Manufacturers All Listing: Set this to 1 if you want the manufacturers URL to appear with the listing.', @gid, '7', now(), now(), NULL, 'zen_cfg_select_option(array(\'0\', \'1\'),'),
('Manufacturers Per Row', 'MANUFACTURERS_ALL_COLUMNS', '3', 'Manufacturers All Listing: Set the number of manufacturers per row to display.<br>(default 4)', @gid, '7', now(), now(), NULL, NULL),
('Manufacturer Image Width', 'MANUFACTURERS_ALL_WIDTH', '175px', 'Manufacturers All Listing: Set the maximum width of the manufacturers image.<br>(default 100px)', @gid, '7', now(), now(), NULL, NULL),
('Manufacturer Image Height', 'MANUFACTURERS_ALL_HEIGHT', '0px', 'Manufacturers All Listing: Set the maximum height of the manufacturers image<br>(default 100px)', @gid, '7', now(), now(), NULL, NULL);

INSERT INTO admin_pages (page_key ,language_key ,main_page ,page_params ,menu_key ,display_on_menu ,sort_order)VALUES 
('configManufacturersList', 'BOX_CONFIGURATION_MANUFACTURERS_LIST', 'FILENAME_CONFIGURATION', CONCAT('gID=',@gid), 'configuration', 'Y', @gid);

#
# news
#

CREATE TABLE IF NOT EXISTS box_news (
  box_news_id int(11) NOT NULL auto_increment,
  news_added_date datetime NOT NULL default '0001-01-01 00:00:00',
  news_modified_date datetime default NULL,
  news_start_date datetime default NULL,
  news_end_date datetime default NULL,
  news_status tinyint(1) default '0',
  PRIMARY KEY  (box_news_id)
);

INSERT INTO box_news (news_added_date, news_modified_date, news_start_date, news_end_date, news_status) VALUES
('2015-09-24 11:03:20', '2016-08-20 08:34:54', '2015-09-23 00:00:00', '2017-09-23 00:00:00', 1),
('2015-09-25 11:48:02', '2016-08-20 08:32:02', '2015-09-23 00:00:00', '2017-09-23 00:00:00', 1),
('2015-09-23 11:50:59', '2016-08-20 08:35:38', '2015-09-23 00:00:00', '2017-09-23 00:00:00', 1),
('2016-06-21 09:22:11', '2016-08-20 08:34:06', '2016-06-21 00:00:00', '2017-09-23 00:00:00', 1);

CREATE TABLE IF NOT EXISTS box_news_content (
  box_news_id int(11) NOT NULL default '0',
  languages_id int(11) NOT NULL default '1',
  news_title varchar(255) NOT NULL default '',
  news_content text NOT NULL,
  PRIMARY KEY  (languages_id,box_news_id)
);

ALTER TABLE box_news_content ADD news_image TEXT NOT NULL AFTER news_content;

INSERT INTO box_news_content (box_news_id, languages_id, news_title, news_content, news_image) VALUES
(1, 1, 'The standard Lorem', '<p>Shoe street style leather tote oversized sweatshirt A.P.C. Prada Saffiano crop slipper denim shorts spearmint. Braid skirt round sunglasses seam leather vintage Levi plaited. Flats holographic Acne grunge collarless denim chunky sole cuff tucked t-shirt strong eyebrows. Clutch center part dress dungaree slip dress. </p>\r\n<p>Skinny jeans knitwear minimal tortoise-shell sunglasses Céline sandal Cara D. lilac. Black floral 90s oxford chambray bomber powder blue cotton boots print. Cable knit knot ponytail ribbed sneaker sports luxe pastel Paris. Washed out skort white shirt Hermès vintage Givenchy razor pleats. Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. </p>\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt. Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau.</p>\r\n<p>Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe. Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-04.jpg'),
(2, 1, 'Lorem ipsum dolor', '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia dolore consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo dolore voluptas nulla pariatur ut labore et dolore magnam aliquam quaerat voluptatem</p>', 'post-gallery-img-08.jpg'),
(3, 1, 'Section of de Finibus', '<p>Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt.</p>\r\n<p>Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau. Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe.</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-11.jpg'),
(4, 1, 'dolore magna aliqua', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque. Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate.\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>', 'post-gallery-img-12.jpg'),
(1, 2, 'The standard Lorem', '<p>Shoe street style leather tote oversized sweatshirt A.P.C. Prada Saffiano crop slipper denim shorts spearmint. Braid skirt round sunglasses seam leather vintage Levi plaited. Flats holographic Acne grunge collarless denim chunky sole cuff tucked t-shirt strong eyebrows. Clutch center part dress dungaree slip dress. </p>\r\n<p>Skinny jeans knitwear minimal tortoise-shell sunglasses Céline sandal Cara D. lilac. Black floral 90s oxford chambray bomber powder blue cotton boots print. Cable knit knot ponytail ribbed sneaker sports luxe pastel Paris. Washed out skort white shirt Hermès vintage Givenchy razor pleats. Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. </p>\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt. Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau.</p>\r\n<p>Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe. Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-04.jpg'),
(2, 2, 'Lorem ipsum dolor', '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia dolore consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo dolore voluptas nulla pariatur ut labore et dolore magnam aliquam quaerat voluptatem</p>', 'post-gallery-img-08.jpg'),
(3, 2, 'Section of de Finibus', '<p>Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt.</p>\r\n<p>Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau. Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe.</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-11.jpg'),
(4, 2, 'dolore magna aliqua', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque. Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate.\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>', 'post-gallery-img-12.jpg'),
(1, 3, 'The standard Lorem', '<p>Shoe street style leather tote oversized sweatshirt A.P.C. Prada Saffiano crop slipper denim shorts spearmint. Braid skirt round sunglasses seam leather vintage Levi plaited. Flats holographic Acne grunge collarless denim chunky sole cuff tucked t-shirt strong eyebrows. Clutch center part dress dungaree slip dress. </p>\r\n<p>Skinny jeans knitwear minimal tortoise-shell sunglasses Céline sandal Cara D. lilac. Black floral 90s oxford chambray bomber powder blue cotton boots print. Cable knit knot ponytail ribbed sneaker sports luxe pastel Paris. Washed out skort white shirt Hermès vintage Givenchy razor pleats. Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. </p>\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt. Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau.</p>\r\n<p>Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe. Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-04.jpg'),
(2, 3, 'Lorem ipsum dolor', '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia dolore consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo dolore voluptas nulla pariatur ut labore et dolore magnam aliquam quaerat voluptatem</p>', 'post-gallery-img-08.jpg'),
(3, 3, 'Section of de Finibus', '<p>Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt.</p>\r\n<p>Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau. Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe.</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-11.jpg'),
(4, 3, 'dolore magna aliqua', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque. Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate.\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>', 'post-gallery-img-12.jpg'),
(1, 4, 'The standard Lorem', '<p>Shoe street style leather tote oversized sweatshirt A.P.C. Prada Saffiano crop slipper denim shorts spearmint. Braid skirt round sunglasses seam leather vintage Levi plaited. Flats holographic Acne grunge collarless denim chunky sole cuff tucked t-shirt strong eyebrows. Clutch center part dress dungaree slip dress. </p>\r\n<p>Skinny jeans knitwear minimal tortoise-shell sunglasses Céline sandal Cara D. lilac. Black floral 90s oxford chambray bomber powder blue cotton boots print. Cable knit knot ponytail ribbed sneaker sports luxe pastel Paris. Washed out skort white shirt Hermès vintage Givenchy razor pleats. Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. </p>\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt. Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau.</p>\r\n<p>Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe. Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-04.jpg'),
(2, 4, 'Lorem ipsum dolor', '<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia dolore consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n<p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo dolore voluptas nulla pariatur ut labore et dolore magnam aliquam quaerat voluptatem</p>', 'post-gallery-img-08.jpg'),
(3, 4, 'Section of de Finibus', '<p>Lanvin flats seam cotton minimal Saint Laurent midi Céline la marinière. Powder blue playsuit oversized sweatshirt bomber chunky sole street style chignon vintage. Dress Jil Sander Vasari chambray boots luxe. Statement button up navy blue slip dress skinny jeans indigo white shirt.</p>\r\n<p>Maison Martin Margiela cami texture la marinière ecru envelope clutch So-Cal relaxed silhouette. Cashmere chunky sole center part round sunglasses holographic skirt sneaker Acne bandeau. Leggings Lanvin plaited ribbed sports luxe Paris white metallic cami. Givenchy clutch black Furla navy blue grunge dress luxe.</p>\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>\r\n\r\n<p>Oversized sweatshirt strong eyebrows knot ponytail indigo playsuit A.P.C. Floral gold collar Maison Martin Margiela vintage relaxed la marinière statement button up tee. Razor pleats chignon boots So-Cal cable knit seam denim chambray flats Prada Saffiano. Leather leather tote neutral denim shorts collarless Cara D. washed out. 90s vintage Levi texture envelope clutch crop ecru skinny jeans. Rings loafer Céline pastel sandal dove grey cotton Hermès.</p>', 'post-gallery-img-11.jpg'),
(4, 4, 'dolore magna aliqua', 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque. Lorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate.\r\n\r\n<blockquote class="quote-left">\r\n<p>\r\nLorem ipsum dolor sit amet conse ctetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip.\r\n</p>\r\n<cite> <b>Amanda Smith</b> - designer</cite>\r\n</blockquote>', 'post-gallery-img-12.jpg');

#
# testimonials
#

CREATE TABLE IF NOT EXISTS testimonials_manager (
  testimonials_id int(11) NOT NULL auto_increment,
  language_id int(11) NOT NULL default '1',
  testimonials_title varchar(64) NOT NULL default '',
  testimonials_url  VARCHAR( 255 ) NULL DEFAULT NULL,
  testimonials_name text NOT NULL,
  testimonials_image varchar(254) NOT NULL default '',
  testimonials_html_text text,
  testimonials_mail text NOT NULL,
  testimonials_company VARCHAR( 255 ) NULL DEFAULT NULL,
  testimonials_city VARCHAR( 255 ) NULL DEFAULT NULL,
  testimonials_country VARCHAR( 255 ) NULL DEFAULT NULL,
  testimonials_show_email char(1) default '0',
  status int(1) NOT NULL default '0',
  date_added datetime NOT NULL default '0001-01-01 00:00:00',
  last_update datetime NULL default NULL,
  PRIMARY KEY  (testimonials_id)
);

INSERT INTO testimonials_manager (language_id, testimonials_title, testimonials_url, testimonials_name, testimonials_image, testimonials_html_text, testimonials_mail, testimonials_company, testimonials_city, testimonials_country, testimonials_show_email, status, date_added, last_update) VALUES
(1, 'Customer Support', 'http://', 'PhaytalError', 'testimonials/slider-blog-img01.jpg', 'A very high quality Zen Cart template with many options and customizability. Highly recommended and well worth the money! Customer service is nothing short of amazing with responses with-in hours, and bugs often fixed within hours. Keep up the great work!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2036-12-15 00:00:00', '2016-06-18 08:24:54'),
(1, 'Design Quality', 'http://', 'Wang', 'testimonials/slider-blog-img02.jpg', 'This is the second time i bought from them, always good, nice design and features, very easy to use. I have to say their customer service is the best, always reply and solve the problems quickly.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-08-20 00:00:00', '2016-06-18 08:25:07'),
(1, 'Design Quality', 'http://', 'MoeyBell', 'testimonials/slider-blog-img03.jpg', 'This template is great. Perfectus also has fabulous support and they have helped me to get the website perfect. Thank you :D', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-07-20 00:00:00', '2016-06-18 08:25:20'),
(1, 'Customer Support', 'http://', 'Jason', 'testimonials/slider-blog-img01.jpg', 'Not like any service i have ever experienced with any other template purchase. AWESOME team to work with. Forget the rest as this is also the easiest template I have ever worked set up. Well done it is PERFECTus Jason Van Kuijk Skin Revival 5+yrs Ecommerce Over $5m in online sales 15,000 zencart orders', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-06-20 00:00:00', '2016-06-18 08:25:37'),
(1, 'Customer Support', 'http://', 'Kimtownsend', 'testimonials/slider-blog-img02.jpg', 'I\'ve purchased many themes throughout the years and I\'ve never had customer service like this. Stellar! AMAZING!! I cannot stay enough positive things about this company/author. Thank you!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:48'),
(1, 'Design Quality', 'http://', 'Emendy', 'testimonials/slider-blog-img03.jpg', 'Thank you so much for a clean, effective and excellent Zen Cart Template. The template is easy to use and very customizable. The support form the author for this template is fantastic and they will go out of their way to help making the template work 100% as well as small customizations related to the template itself.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:59'),
(2, 'Customer Support', 'http://', 'PhaytalError', 'testimonials/slider-blog-img01.jpg', 'A very high quality Zen Cart template with many options and customizability. Highly recommended and well worth the money! Customer service is nothing short of amazing with responses with-in hours, and bugs often fixed within hours. Keep up the great work!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2036-12-15 00:00:00', '2016-06-18 08:24:54'),
(2, 'Design Quality', 'http://', 'Wang', 'testimonials/slider-blog-img02.jpg', 'This is the second time i bought from them, always good, nice design and features, very easy to use. I have to say their customer service is the best, always reply and solve the problems quickly.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-08-20 00:00:00', '2016-06-18 08:25:07'),
(2, 'Design Quality', 'http://', 'MoeyBell', 'testimonials/slider-blog-img03.jpg', 'This template is great. Perfectus also has fabulous support and they have helped me to get the website perfect. Thank you :D', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-07-20 00:00:00', '2016-06-18 08:25:20'),
(2, 'Customer Support', 'http://', 'Jason', 'testimonials/slider-blog-img01.jpg', 'Not like any service i have ever experienced with any other template purchase. AWESOME team to work with. Forget the rest as this is also the easiest template I have ever worked set up. Well done it is PERFECTus Jason Van Kuijk Skin Revival 5+yrs Ecommerce Over $5m in online sales 15,000 zencart orders', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-06-20 00:00:00', '2016-06-18 08:25:37'),
(2, 'Customer Support', 'http://', 'Kimtownsend', 'testimonials/slider-blog-img02.jpg', 'I\'ve purchased many themes throughout the years and I\'ve never had customer service like this. Stellar! AMAZING!! I cannot stay enough positive things about this company/author. Thank you!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:48'),
(2, 'Design Quality', 'http://', 'Emendy', 'testimonials/slider-blog-img03.jpg', 'Thank you so much for a clean, effective and excellent Zen Cart Template. The template is easy to use and very customizable. The support form the author for this template is fantastic and they will go out of their way to help making the template work 100% as well as small customizations related to the template itself.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:59'),
(2, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:00', NULL),
(2, 'Customer Support', NULL, 'Zark', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:54', NULL),
(2, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:21:00', NULL),
(3, 'Customer Support', 'http://', 'PhaytalError', 'testimonials/slider-blog-img01.jpg', 'A very high quality Zen Cart template with many options and customizability. Highly recommended and well worth the money! Customer service is nothing short of amazing with responses with-in hours, and bugs often fixed within hours. Keep up the great work!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2036-12-15 00:00:00', '2016-06-18 08:24:54'),
(3, 'Design Quality', 'http://', 'Wang', 'testimonials/slider-blog-img02.jpg', 'This is the second time i bought from them, always good, nice design and features, very easy to use. I have to say their customer service is the best, always reply and solve the problems quickly.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-08-20 00:00:00', '2016-06-18 08:25:07'),
(3, 'Design Quality', 'http://', 'MoeyBell', 'testimonials/slider-blog-img03.jpg', 'This template is great. Perfectus also has fabulous support and they have helped me to get the website perfect. Thank you :D', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-07-20 00:00:00', '2016-06-18 08:25:20'),
(3, 'Customer Support', 'http://', 'Jason', 'testimonials/slider-blog-img01.jpg', 'Not like any service i have ever experienced with any other template purchase. AWESOME team to work with. Forget the rest as this is also the easiest template I have ever worked set up. Well done it is PERFECTus Jason Van Kuijk Skin Revival 5+yrs Ecommerce Over $5m in online sales 15,000 zencart orders', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-06-20 00:00:00', '2016-06-18 08:25:37'),
(3, 'Customer Support', 'http://', 'Kimtownsend', 'testimonials/slider-blog-img02.jpg', 'I\'ve purchased many themes throughout the years and I\'ve never had customer service like this. Stellar! AMAZING!! I cannot stay enough positive things about this company/author. Thank you!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:48'),
(3, 'Design Quality', 'http://', 'Emendy', 'testimonials/slider-blog-img03.jpg', 'Thank you so much for a clean, effective and excellent Zen Cart Template. The template is easy to use and very customizable. The support form the author for this template is fantastic and they will go out of their way to help making the template work 100% as well as small customizations related to the template itself.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:59'),
(3, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:00', NULL),
(3, 'Customer Support', NULL, 'Zark', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:54', NULL),
(3, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:21:00', NULL),
(4, 'Customer Support', 'http://', 'PhaytalError', 'testimonials/slider-blog-img01.jpg', 'A very high quality Zen Cart template with many options and customizability. Highly recommended and well worth the money! Customer service is nothing short of amazing with responses with-in hours, and bugs often fixed within hours. Keep up the great work!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2036-12-15 00:00:00', '2016-06-18 08:24:54'),
(4, 'Design Quality', 'http://', 'Wang', 'testimonials/slider-blog-img02.jpg', 'This is the second time i bought from them, always good, nice design and features, very easy to use. I have to say their customer service is the best, always reply and solve the problems quickly.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-08-20 00:00:00', '2016-06-18 08:25:07'),
(4, 'Design Quality', 'http://', 'MoeyBell', 'testimonials/slider-blog-img03.jpg', 'This template is great. Perfectus also has fabulous support and they have helped me to get the website perfect. Thank you :D', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-07-20 00:00:00', '2016-06-18 08:25:20'),
(4, 'Customer Support', 'http://', 'Jason', 'testimonials/slider-blog-img01.jpg', 'Not like any service i have ever experienced with any other template purchase. AWESOME team to work with. Forget the rest as this is also the easiest template I have ever worked set up. Well done it is PERFECTus Jason Van Kuijk Skin Revival 5+yrs Ecommerce Over $5m in online sales 15,000 zencart orders', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-06-20 00:00:00', '2016-06-18 08:25:37'),
(4, 'Customer Support', 'http://', 'Kimtownsend', 'testimonials/slider-blog-img02.jpg', 'I\'ve purchased many themes throughout the years and I\'ve never had customer service like this. Stellar! AMAZING!! I cannot stay enough positive things about this company/author. Thank you!', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:48'),
(4, 'Design Quality', 'http://', 'Emendy', 'testimonials/slider-blog-img03.jpg', 'Thank you so much for a clean, effective and excellent Zen Cart Template. The template is easy to use and very customizable. The support form the author for this template is fantastic and they will go out of their way to help making the template work 100% as well as small customizations related to the template itself.', 'contact.perfectus@gmail.com', '', '', '', '0', 1, '2015-04-15 00:00:00', '2016-06-18 08:25:59'),
(4, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:00', NULL),
(4, 'Customer Support', NULL, 'Zark', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:13:54', NULL),
(4, 'Customer Support', NULL, 'Nishant Patel', '', 'Support with post installation config issues has been brilliant. Would feel totally confident purchasing another theme by this author.', 'admin@perfectusinc.com', '', 'Melbourne', 'VIC, Australia', '', 1, '2016-08-19 14:21:00', NULL);

#
# Structured Data - Install
#

#Install new constants
INSERT INTO configuration_group (configuration_group_title, configuration_group_description, sort_order, visible) VALUES 
('Structured Data', 'Set Structured Data Options', '1', '1');

SET @configuration_group_id=last_insert_id();
UPDATE configuration_group SET sort_order = @configuration_group_id WHERE configuration_group_id = @configuration_group_id;

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added, use_function, set_function) VALUES 
('Enable Structured Data generation', 'PLUGIN_SDATA_ENABLE', 'false', 'Enable Structured Data processing code and display of markup groups? This is a global option.', @configuration_group_id, 1, NOW(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
('Enable Schema markup', 'PLUGIN_SDATA_SCHEMA_ENABLE', 'false', 'Show Schema markup?<br />Shows JSON-LD blocks for Organisation and Breadcrumbs on all pages, Product on product pages.', @configuration_group_id, 2, NOW(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
('Enable Facebook-Open Graph markup', 'PLUGIN_SDATA_FOG_ENABLE', 'false', 'Show Facebook-Open Graph markup?<br />Shows Facebook og tags on all pages with additional product-specific tags on product pages.', @configuration_group_id, 3, NOW(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
('Enable Twitter Card markup', 'PLUGIN_SDATA_TWITTER_CARD_ENABLE', 'false', 'Show Twitter Card markup?<br />Shows on all pages.', @configuration_group_id, 4, NOW(), NULL, 'zen_cfg_select_option(array(\'true\', \'false\'),'),
('Facebook Application ID', 'PLUGIN_SDATA_FOG_APPID', '', 'Enter your Facebook application ID (<a href="http://developers.facebook.com/setup/" target="_blank">Get an application ID</a>).', @configuration_group_id, 5, NOW(), NULL, NULL),
('Facebook Admin ID (optional)', 'PLUGIN_SDATA_FOG_ADMINID', '', 'Enter the Admin ID(s) of the Facebook user(s) that administer your Facebook fan page separated by commas. <a href="http://www.facebook.com/insights/" target="_blank">Insights for your domain</a>.', @configuration_group_id, 6, NOW(), NULL, NULL),
('Facebook Page (optional)', 'PLUGIN_SDATA_FOG_PAGE', '', 'Enter the full url/link to your facebook page eg.:https://www.facebook.com/zencart/.', @configuration_group_id, 7, NOW(), NULL, NULL),
('Logo (Schema)', 'PLUGIN_SDATA_LOGO', '', 'Enter the full url to your logo image.', @configuration_group_id, 10, NOW(), NULL, NULL),
('Street Address (Schema/OG)', 'PLUGIN_SDATA_STREET_ADDRESS', '', 'Enter the business street address.', @configuration_group_id, 11, NOW(), NULL, NULL),
('City (Schema/OG)', 'PLUGIN_SDATA_LOCALITY', '', 'Enter the business town/city.', @configuration_group_id, 12, NOW(), NULL, NULL),
('State (Schema/OG)', 'PLUGIN_SDATA_REGION', '', 'Enter the business state/province.', @configuration_group_id, 13, NOW(), NULL, NULL),
('Postal Code (Schema/OG)', 'PLUGIN_SDATA_POSTALCODE', '', 'Enter the business postal code/zip', @configuration_group_id, 14, NOW(), NULL, NULL),
('Country (Schema/OG)', 'PLUGIN_SDATA_COUNTRYNAME', '', 'Enter the business country name or <a href="https://en.wikipedia.org/wiki/ISO_3166-1" target="_blank">2 letter ISO code</a>', @configuration_group_id, 15, NOW(), NULL, NULL),
('Email (Schema, optional)', 'PLUGIN_SDATA_EMAIL', '', 'Enter your customer service email address (lower case).', @configuration_group_id, 16, NOW(), NULL, NULL),
('Phone (Schema)', 'PLUGIN_SDATA_TELEPHONE', '', 'Enter the customer service phone number in international format eg.: +1-330-871-4357. Format (spaces/dashes) is not important.', @configuration_group_id, 17, NOW(), NULL, NULL),
('Fax (Schema, optional)', 'PLUGIN_SDATA_FAX', '', 'Enter the customer service fax number in international format eg.: +1-877-453-1304).', @configuration_group_id, 18, NOW(), NULL, NULL),
('Available Languages (Schema, optional)', 'PLUGIN_SDATA_AVAILABLE_LANGUAGE', '', 'Languages spoken (for Schema contact point). Enter the language\'s english name, separated by commas. If omitted, the language defaults to English.', @configuration_group_id, 19, NOW(), NULL, NULL),
('Locales (OG)', 'PLUGIN_SDATA_FOG_LOCALES', '', 'Enter a comma-separated list of the database language_id and equivalent locale for each defined language eg.: 1,en_GB,2,es_ES, etc. (no spaces).<br />Separate the urls with commas.', @configuration_group_id, 22, NOW(), NULL, NULL),
('Tax ID (Schema, optional)', 'PLUGIN_SDATA_TAXID', '', 'The Tax/Fiscal ID of the business (eg. the TIN in the US or the CIF/NIF in Spain).', @configuration_group_id, 20, NOW(), NULL, NULL),
('VAT Number (Schema, optional)', 'PLUGIN_SDATA_VATID', '', 'Value-added Tax ID of the business.', @configuration_group_id, 21, NOW(), NULL, NULL),
('Profile/Social Pages (Schema-sameAs, optional)', 'PLUGIN_SDATA_SAMEAS', '', 'Enter a list of urls to other (NOT Facebook, Twitter or Google Plus) profile or social pages related to your business (eg. Linked In, Dun & Bradstreet, Yelp etc.).<br />Separate the urls with commas.', @configuration_group_id, 22, NOW(), NULL, NULL),
('Product Shipping Area (Schema, optional)', 'PLUGIN_SDATA_ELIGIBLE_REGION', '', 'Area to which you ship products.<br >Use the ISO 3166-1 (ISO 3166-1 alpha-2) or ISO 3166-2 code, or the GeoShape for the geo-political region(s).', @configuration_group_id, 23, NOW(), NULL, NULL),
('Currency (Schema/OG)', 'PLUGIN_SDATA_PRICE_CURRRENCY', '', 'Enter the currency code of the product price eg.: EUR.', @configuration_group_id, 24, NOW(), NULL, NULL),
('Product Delivery Time when in stock (Schema)', 'PLUGIN_SDATA_DELIVERYLEADTIME', '', 'Enter the average days from order to delivery when product is in stock (eg.:2).', @configuration_group_id, 25, NOW(), NULL, NULL),
('Product Delivery Time when out of stock (Schema)', 'PLUGIN_SDATA_DELIVERYLEADTIME_OOS', '', 'Enter the average days from order to delivery when product is out of stock (eg.:7).', @configuration_group_id, 25, NOW(), NULL, NULL),
('Product Condition (Schema/OG)', 'PLUGIN_SDATA_FOG_PRODUCT_CONDITION', 'new', 'Choose your product\'s condition.', @configuration_group_id, 27, NOW(), NULL, 'zen_cfg_select_option(array(\'new\', \'used\', \'refurbished\'),'),
('Accepted Payment Methods (Schema)', 'PLUGIN_SDATA_ACCEPTED_PAYMENT_METHODS', 'ByBankTransferInAdvance, ByInvoice, Cash, CheckInAdvance, COD, DirectDebit, GoogleCheckout, PayPal, PaySwarm, AmericanExpress, DinersClub, Discover, JCB, MasterCard, VISA', 'List/delete as aplicable the <a href="http://www.heppnetz.de/ontologies/goodrelations/v1#PaymentMethod" target="_blank">accepted payment methods</a>. eg. ByBankTransferInAdvance, ByInvoice, Cash, CheckInAdvance, COD, DirectDebit, GoogleCheckout, PayPal, PaySwarm, AmericanExpress, DinersClub, Discover, JCB, MasterCard, VISA.', @configuration_group_id, 28, NOW(), NULL, NULL),
('Legal Name (Schema, optional)', 'PLUGIN_SDATA_LEGAL_NAME', '', 'The registered company name.', @configuration_group_id, 29, NOW(), NULL, NULL),
('Dun & Bradstreet DUNS number (Schema, optional)', 'PLUGIN_SDATA_DUNS', '', 'The Dun & Bradstreet DUNS number for identifying an organization or business person.', @configuration_group_id, 30, NOW(), NULL, NULL),
('Area Served (Schema-Customer Service, optional)', 'PLUGIN_SDATA_AREA_SERVED', '', 'The geographical region served (<a href="https://schema.org/areaServed" target="_blank">further details here</a>).<br />If omitted, the area is assumed to be global.)', @configuration_group_id, 31, NOW(), NULL, NULL),

('Facebook Default Image: Product (optional)', 'PLUGIN_SDATA_FOG_DEFAULT_PRODUCT_IMAGE', '', 'Fallback image used in Facebook when there is no product image. Enter the full url or leave blank to use the no-image file defined in the Admin->Images configuration.', @configuration_group_id, 35, NOW(), NULL, NULL),
('Facebook Default Image: non Product (optional)', 'PLUGIN_SDATA_FOG_DEFAULT_IMAGE', '', 'Fallback image used in Facebook when there is no image on any page other than a product page. Enter the full url or leave blank to use the logo file defined above.', @configuration_group_id, 36, NOW(), NULL, NULL),
('Facebook Type - Non Product Page', 'PLUGIN_SDATA_FOG_TYPE_SITE', 'business.business', 'Enter an Open Graph type for your site - non-product pages (<a href="https://developers.facebook.com/docs/reference/opengraph/" target="_blank">Open Graph Types</a>)', @configuration_group_id, 37, NOW(), NULL, NULL),
('Facebook Type - Product Page', 'PLUGIN_SDATA_FOG_TYPE_PRODUCT', 'product', 'Enter an Open Graph type for your site - product pages (<a href="https://developers.facebook.com/docs/reference/opengraph/" target="_blank">Open Graph Types</a>)', @configuration_group_id, 38, NOW(), NULL, NULL),
('Twitter Default Image (optional)', 'PLUGIN_SDATA_TWITTER_DEFAULT_IMAGE', '', 'Fallback image used in Twitter when there is no image defined. Enter the full url.', @configuration_group_id, 39, NOW(), NULL, NULL),
('Twitter Username', 'PLUGIN_SDATA_TWITTER_USERNAME', '', 'Enter your Twitter username (eg.: @zencart).', @configuration_group_id, 40, NOW(), NULL, NULL),
('Twitter Page URL', 'PLUGIN_SDATA_TWITTER_PAGE', '', 'Enter the full url to your Twitter page (eg.: https://twitter.com/zencart)', @configuration_group_id, 41, NOW(), NULL, NULL),
('Google Publisher', 'PLUGIN_SDATA_GOOGLE_PUBLISHER', '', 'Enter your Google Publisher url/link (eg.: https://plus.google.com/+Pro-websNet/). Link does not display if field empty.', @configuration_group_id, 42, NOW(), NULL, NULL);

# Register the configuration page for Admin Access Control
INSERT IGNORE INTO admin_pages (page_key,language_key,main_page,page_params,menu_key,display_on_menu,sort_order) VALUES ('configStructuredData','BOX_CONFIGURATION_STRUCTURED_DATA','FILENAME_CONFIGURATION',CONCAT('gID=',@configuration_group_id),'configuration','Y',@configuration_group_id);
