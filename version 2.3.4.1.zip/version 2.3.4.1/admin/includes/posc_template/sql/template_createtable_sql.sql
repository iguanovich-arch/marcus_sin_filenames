CREATE TABLE IF NOT EXISTS pzen_alto_template (
	opt_id int(11) NOT NULL AUTO_INCREMENT,
	lang_id int(11) NOT NULL DEFAULT '0',
	opt_name varchar(255) COLLATE utf8_unicode_ci NOT NULL,
	opt_value text COLLATE utf8_unicode_ci NOT NULL,
	PRIMARY KEY (opt_id)
);

CREATE TABLE IF NOT EXISTS pzen_alto_topbanner (
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS pzen_alto_bottombanner (
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS pzen_alto_sidebarbanner(
  id int(11) NOT NULL AUTO_INCREMENT,
  item_type int(11) NOT NULL COMMENT '1=Slide, 2=Banner',
  sort_order int(11) NOT NULL,
  item_image varchar(200) NOT NULL,
  item_desc text NOT NULL,
  item_link text NOT NULL,
  created_at datetime NOT NULL default '0001-01-01 00:00:00',
  updated_at datetime NOT NULL default '0001-01-01 00:00:00',
  item_status enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
);