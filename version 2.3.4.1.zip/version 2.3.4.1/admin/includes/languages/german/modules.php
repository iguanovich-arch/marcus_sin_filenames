<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_MODULES', 'Module');
define('TABLE_HEADING_SORT_ORDER', 'Reihenfolge');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_VERSION', 'Version:');
define('TEXT_INFO_ONLINE_STATUS', 'online Status');
define('TEXT_INFO_API_VERSION', 'API Version:');

define('TEXT_MODULE_DIRECTORY', 'Modul Verzeichnis:');
?>
