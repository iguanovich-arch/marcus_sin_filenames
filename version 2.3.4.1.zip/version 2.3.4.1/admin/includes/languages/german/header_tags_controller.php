<?php
/*
  $Id: header_tags.php,v 1.6 2005/04/10 14:07:36 hpdl Exp $
  Created by Jack York from http://www.oscommerce-solution.com
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
define('HEADING_TITLE_CONTROLLER', 'Header Tags Controller');
define('HEADING_TITLE_ENGLISH', 'Header Tags - English');
define('HEADING_TITLE_INCLUDES', 'Header Tags - Includes');
define('TEXT_INFORMATION_ADD_PAGE', 'Add a New Page'); 
define('TEXT_INFORMATION_DELETE_PAGE', 'Delete a New Page'); 
define('TEXT_INFORMATION_CHECK_PAGES', 'Check Missing Pages'); 
?>
