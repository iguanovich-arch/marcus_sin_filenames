<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TEXT_COUNT_CUSTOMERS', 'Kunden die Newsletter empfangen: %s');
define('TEXT_PRODUCTS', 'Produkte');
define('TEXT_SELECTED_PRODUCTS', 'Ausgewählte Produkte');

define('JS_PLEASE_SELECT_PRODUCTS', 'Wählen Sie bitte einige Produkte.');

define('BUTTON_GLOBAL', 'Global');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'übermitteln');
define('BUTTON_CANCEL', 'Löschen');
?>