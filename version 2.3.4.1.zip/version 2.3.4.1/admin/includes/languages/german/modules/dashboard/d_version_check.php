<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_TITLE', 'Versions Check');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DESCRIPTION', 'Zeige die Version Check Resultate');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_DATE', 'Zuletzt geprüft');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_CHECK_NOW', 'Prüfe jetzt');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_NEVER', 'Nie');
define('MODULE_ADMIN_DASHBOARD_VERSION_CHECK_UPDATE_AVAILABLE', 'Ein update füer osCommerce Online Merchant ist verfüegbar!');
?>
