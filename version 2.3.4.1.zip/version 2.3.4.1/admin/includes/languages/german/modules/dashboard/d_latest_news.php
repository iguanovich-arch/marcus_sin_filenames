<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_TITLE', 'Letzten News');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DESCRIPTION', 'Die letzten osCommerce News');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_DATE', 'Datum');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_FEED_ERROR', 'Could not connect to the osCommerce News feed. The next attempt will be performed within 24 hours.');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWS', 'Lies die letzen osCommerce News');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_NEWSLETTER', 'Registrieren für den osCommerce Newsletter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_GOOGLE_PLUS', 'Circle osCommerce on Google+');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_FACEBOOK', 'werde ein osCommerce Fan auf Facebook');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_TWITTER', 'folge osCommerce auf Twitter');
define('MODULE_ADMIN_DASHBOARD_LATEST_NEWS_ICON_RSS', 'Registriere die für den osCommerce News RSS Feed');
?>
