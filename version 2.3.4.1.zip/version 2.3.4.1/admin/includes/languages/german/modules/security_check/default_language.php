<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('ERROR_NO_DEFAULT_LANGUAGE_DEFINED', 'Error: Es gibt z.Z. keine Standard Sprache. Bitte setzten Sie eine Standard Sprache unter: Administration->Sprachen/Währungen->Sprache');
?>
