<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_TITLE', 'Admin HTTP Authentication');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_HTTP_AUTHENTICATION_ERROR', 'HTTP Authentication has not been set up for the osCommerce Administration Tool - please set this up in your web server configuration to further protect the Administration Tool from unauthorized access.');
?>
