<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_LAST_RUN_OLD', 'Es ist über 30 Tage her, das der extendend Sexurity Check durchgeführt wurde. Bitte machen Sie den Security Check under Tools -&gt; Sicherheitschecks (Security Checks).');
?>
