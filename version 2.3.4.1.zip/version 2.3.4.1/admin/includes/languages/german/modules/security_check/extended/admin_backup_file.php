<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_TITLE', 'admin/backups/ File Access');
define('MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_HTTP_200', 'Backup files in ' . DIR_WS_ADMIN . 'backups/ can be accessed and downloaded directly - please disable public access to this directory in your web server configuration.');
?>
