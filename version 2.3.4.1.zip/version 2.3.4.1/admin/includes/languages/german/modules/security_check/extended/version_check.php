<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE', 'Version Check');
define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR', 'Sie haben schon über 30 Tage keinen Versions-Check gemacht. Bitte überprüfen Sie, ob eine neuere Version verfügbar ist.');
?>
