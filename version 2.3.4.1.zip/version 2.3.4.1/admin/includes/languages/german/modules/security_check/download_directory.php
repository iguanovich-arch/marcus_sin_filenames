<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT', 'Das "Runterladbare Produkte (Downloadable Produkts)" Verzeichnis existiert nicht: ' . DIR_FS_DOWNLOAD . '. Runterladbare Produkte (Downloadable Produkts) arbeitet nicht, bis dieses Verzeichnis gültig ist.');
?>
