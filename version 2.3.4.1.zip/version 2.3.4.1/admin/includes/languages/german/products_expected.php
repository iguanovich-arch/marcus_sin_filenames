<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'erwartete Artikel');

define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_DATE_EXPECTED', 'verfügbar ab:');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_DATE_EXPECTED', 'verfügbar ab:');
?>
