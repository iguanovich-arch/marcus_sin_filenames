<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Shop Logo');

define('TEXT_LOGO_IMAGE', 'Neues Logo:');
define('TEXT_FORMAT_AND_LOCATION', 'Das Shop Logo muss im Format PNG sein, und gespeichert werden als:');

define('SUCCESS_LOGO_UPDATED', 'Success: Das Shop Logo wurde erfolgreich aktualisiert!');

define('ERROR_IMAGES_DIRECTORY_NOT_WRITEABLE', 'Error: Das Bildverzeichnis kann nicht aktualisiert werden zu. (<a href="%s">klicken Sie hier um die Verzeichnis-Rechte(directory permissions) zu kontrollieren</a>)');
?>