<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Kunden mit den höchsten Umsätzen');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_CUSTOMERS', 'Kunde');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Gesamtsumme');
?>
