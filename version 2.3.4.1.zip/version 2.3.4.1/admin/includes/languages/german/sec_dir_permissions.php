<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Verzeichnis Sicherheit/Lesezugriffsrecht');

define('TABLE_HEADING_DIRECTORIES', 'Directories/Verzeichnisse');
define('TABLE_HEADING_WRITABLE', 'beschreibbar');
define('TABLE_HEADING_RECOMMENDED', ' vorgeschlagen');

define('TEXT_DIRECTORY', 'Directory/Verzeichnis:');
?>
