<?php
define('TABLE_POSC_TEMPLATE',  'posc_template');
define('TABLE_POSC_MAINSLIDER', 'posc_mainslider');
define('TABLE_POSC_TOPBANNER', 'posc_topbanner');
define('TABLE_POSC_BOTTOMBANNER', 'posc_bottombanner');
define('TABLE_POSC_SIDEBARBANNER', 'posc_sidebarbanner');

define('FILENAME_POSC_TEMPLATE', 'posc_template.php');
define('FILENAME_POSC_TEMPLATE_NAME', 'posc_template');
define('FILENAME_TEMPLATE_SETTINGS', 'posc_template.php');
?>