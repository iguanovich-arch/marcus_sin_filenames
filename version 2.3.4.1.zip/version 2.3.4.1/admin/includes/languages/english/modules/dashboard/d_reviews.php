<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_ADMIN_DASHBOARD_REVIEWS_TITLE', 'Reviews');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DESCRIPTION', 'Show the latest reviews');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEWER', 'Reviewer');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_DATE', 'Date');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_RATING', 'Rating');
define('MODULE_ADMIN_DASHBOARD_REVIEWS_REVIEW_STATUS', 'Status');
?>
