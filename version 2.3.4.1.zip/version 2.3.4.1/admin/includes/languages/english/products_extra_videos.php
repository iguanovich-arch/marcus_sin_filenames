<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

	Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Extra Product Videos');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS_NAME', 'Product Name');

/* Added for product video*/
define('TABLE_HEADING_PRODUCTS_VIDEO', 'Product');
define('TABLE_HEADING_PRODUCTS_VIDEO_PATH', 'YouTube Video URL');
define('TABLE_HEADING_PRODUCTS_EXTRA_VIDEO', 'Extra Video');
/* Added for product video*/

define('TABLE_HEADING_PRODUCTS_ID', 'Products ID');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_PAGING_FORMAT', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> extra videos)');
define('TEXT_HEADING_EDIT_EXTRA_VIDEO', 'Edit Extra Product Video');
define('TEXT_HEADING_NEW_EXTRA_VIDEO', 'New Extra Product Video');
define('TEXT_NEW_INTRO', 'Please fill out the following information for the new extra product video');
define('TEXT_EDIT_INTRO', 'Please make any necessary changes');
define('TEXT_PRODUCTS', 'Number of product:');

define('VIDEO_INSERT', 'Insert');
define('VIDEO_EDIT', 'Edit');
define('VIDEO_DELETE', 'Delete');
define('VIDEO_SAVE', 'Save');
define('VIDEO_CANCEL', 'Cancel');

/* Added for small improvements in upload UI */
define('TEXT_PRODUCTS_NAME', 'Product Name:');
define('TEXT_PRODUCTS_VIDEO', 'YouTube URL Product Video:');

define('TEXT_VIDEO_NONEXISTENT', 'VIDEO DOES NOT EXIST');
define('TEXT_IMAGE_NONEXISTENT', 'IMAGE DOES NOT EXIST');
?>