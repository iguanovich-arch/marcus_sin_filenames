(function($) {
 "use strict"; // Start of use strict  
	$(document).ready(function(){
		//change theme design
		realDesignTemp();
		//window real time action
		$(window).on('shown.bs.modal', function() { 
			realDesignTemp();
		});	
	});

	function realDesignTemp(){
		$('input[type="text"], input[type="password"], input[type="email"], input[type="tel"], textarea, input#state, select').not('.subscribe-box input[type="email"]').addClass('form-control');
	}
	$(document).ready(function(){
		$('body').addClass('loaded');
		$('[data-toggle="tooltip"]').tooltip();
		$('#accordion').on('hidden.bs.collapse', toggleChevron);
		$('#accordion').on('shown.bs.collapse', toggleChevron);
		$(".dropdown-menu li a").on('click', function (){
			var selText = $(this).text();
			$(this).parents('.btn-group').find('.dropdown-toggle').html(selText+' <span class="caret"></span>');
		});
		$(".navbar-brand").on('click', function (){$(".nav-click").show(100);});
		$(".navbar-brand2").on('click', function (){$(".nav-click").hide(100);}); 

		$('a.page-scroll').on('click', function(event) {
			var $anchor = $(this);
			$('html, body').stop().animate({
				scrollTop: ($($anchor.attr('href')).offset().top - 0)
			}, 1250, 'easeInOutExpo');
			event.preventDefault();
		});
		$('body').scrollspy({
			target: '.scroll',
			offset: 0
		})    
		$('#mainNav').affix({offset: {top: (jQuery('.main-menu').offset().top + 10)}});
		$("#back-top").hide();
		
		new WOW().init();
		
		 $('.list-pro-text > span > a').addClass('add-btn');
		  
		var owl = $("#piGal");
		owl.owlCarousel({
			items : 4, //10 items above 1000px browser width
			itemsDesktop : [1400,4], //5 items between 1000px and 901px
			itemsDesktopSmall : [1024,4], // 3 items betweem 900px and 601px
			itemsTablet: [900,4], //2 items between 600 and 0;
			itemsMobile : [480,3],
			rewindNav: false,
			pagination:false,
			navigationText : false,
			navigation : true // itemsMobile disabled - inherit from itemsTablet option
		});
		var owl = $("#mobileGallery");
			owl.owlCarousel({
			items : 2, //10 items above 1000px browser width
			itemsTablet: [768,2], //2 items between 600 and 0;
			itemsMobile : [480,1],
			rewindNav: true,
			navigationText : false,
			pagination:true,
			navigation : true // itemsMobile disabled - inherit from itemsTablet option
		});
	});
	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			$('#back-top').fadeIn();
		} else {
			$('#back-top').fadeOut();
		}
	});
	$('#back-top a').on('click', function () {
		$('body,html').animate({
			scrollTop: 0
		}, 800);
		return false;
	});
	$('.search-hand').on('click',function(){
		$('.header-search').toggleClass("open");
		$('.mainmenu-nav ').toggleClass("show");
	});
	$("#mob-mmenu").mmenu();
	
})(jQuery); // End of use strict
function toggleChevron(e) {
    $(e.target).prev('.panel-heading').find("i.indicator").toggleClass('fa fa-minus fa fa-plus');
}
// desctop menu(popup)
jQuery(document).ready(function () {
	jQuery("nav").each(function(){
		if(!jQuery( this ).hasClass("mainver-nav")) {
			jQuery( this ).find(".dropdown").each(function(){
				jQuery( this ).hover(
					function() {
						var $this = jQuery( this );
						var $obj = $this.find(".dropdown-menu");
						submenuXposition($obj);
						submenuYposition($obj);
						jQuery( window ).bind( "scroll", { obj: $obj }, menuScroll);

					}, function() {
						var $this = jQuery( this );
						$this.find(".dropdown-menu").removeAttr("style");
						jQuery( window ).unbind( "scroll", menuScroll);
					}
				);
			});
		}
	});
});
function submenuXposition($obj){
	var w_width = window.innerWidth;
	if(typeof $obj.offset() !== 'undefined'){
		var o_position = $obj.offset().left;
		var o_width = $obj.outerWidth();
		var delta = parseInt(w_width - o_position - o_width - 25);

		if(delta < 0) {
			$obj.css("left", delta);
		}
	}
}

function submenuYposition($obj){
	var w_height = window.innerHeight;
	if(typeof $obj.offset() !== 'undefined'){
		var o_position = jQuery(".fixed-header-area").hasClass("sticky") ? $obj.position().bottom : $obj.offset().bottom;
		var o_height = $obj.outerHeight();
		var delta = parseInt(w_height - o_position - o_height);
		if(delta < 0) {
			$obj.css({"max-height": o_height + delta - 25, "overflow": "auto"});
		}
	}
}

function menuScroll(event) {
	event.data.obj.removeAttr("style");
	submenuXposition(event.data.obj);
	submenuYposition(event.data.obj)
}
$(document).ready(function(){
	if($('.banners-carousel').length > 0 ){
		$('.banners-carousel').each(function(){
			var owl = $(this);
			var itemPerLine = owl.data('item');
			var itemXl = owl.data('xl');
			var itemLg = owl.data('lg');
			var itemMd = owl.data('md');
			var itemSm = owl.data('sm');
			var itemXs = owl.data('xs');
			var itemAuto = owl.data('auto');
			var sType = owl.data('stype');
			
			productCrousel(owl, itemPerLine, itemLg, itemMd, itemSm, itemXs, itemXs, itemAuto);

		});
	}
	if($('.products-carousel').length > 0 ){
		$('.products-carousel').each(function(){
			var owl = $(this);
			var itemPerLine = owl.data('item');
			var itemLg = owl.data('lg');
			var itemMd = owl.data('md');
			var itemSm = owl.data('sm');
			var itemXs = owl.data('xs');
			var itemXxs = owl.data('xxs');
			var itemAuto = owl.data('auto');
			var sType = owl.data('stype');
			
			productCrousel(owl, itemPerLine, itemLg, itemMd, itemSm, itemXs, itemXxs, itemAuto);
			
		});
	}
});
function productCrousel(carousel, itemPerLine, itemLg, itemMd, itemSm, itemXs, itemXxs, itemAuto, dots, margin) {
	var itemAuto = itemAuto || false;
	var dots = dots || false;
	var marGin = margin || 0;
	var lazyLoader = false;
	if(itemPerLine==1){
		var sgItem = true;
	}else{
		var sgItem = false;
	}
	if(!itemPerLine){
		itemPerLine = 4;
	}
	
	var itemLg = (itemLg > 0) ? itemLg : 4;
	var itemMd = (itemMd > 0) ? itemMd : 3;
	var itemSm = (itemSm > 0) ? itemSm : 2;
	var itemXs = (itemXs > 0) ? itemXs : 1;
	var itemXxs = (itemXxs > 0) ? itemXxs : 1;
	carousel.owlCarousel({
		singleItem:sgItem,
		paginationSpeed : 400,
		navigation : true,
		autoPlay: itemAuto,
		lazyLoad : true,
		items : itemPerLine,
		navigationText : false,
		itemsCustom : [
			[0, 1],
			[360, itemXxs],
			[500, itemXs],
			[767, itemSm],
			[992, itemMd],
			[1199, itemLg],
			[1770, itemPerLine]
		],
		pagination : false,
	});
}
/*-- Product List --*/
$(document).ready(function(){
	pu_prod_list(checkBootstrapMode());
});
$(window).resize(function(){
	pu_prod_list(checkBootstrapMode());
});
function checkBootstrapMode(){
	if (jQuery(window).width() < 480){ return 'xxs';}
	else if(jQuery(window).width() >= 480 && jQuery(window).width() < 768) { return 'xs'; }
	else if(jQuery(window).width() >= 768 && jQuery(window).width() < 992) { return 'sm'; }
	else if (jQuery(window).width() >= 992 && jQuery(window).width() < 1200) { return 'md'; }
	else if (jQuery(window).width() >= 1200 && jQuery(window).width() < 1770) { return 'lg'; }
	else { return 'xl'; }
}
function pu_prod_list(size){
	var colsGrid=jQuery(".productslist-grid");
	if(colsGrid.length > 0){
		colsGrid.each(function(index){
			var parthis=jQuery(this);
			var curdata= parthis.attr("data-"+size);
			if(curdata){
				parthis.children('.clearfix').remove();
				var divs=parthis.children("div.product-item");
				divs.each(function(index){
					var chithis=jQuery(this);
					if((index%curdata==0) && index!=0){
						chithis.before("<div class='clearfix'></div>");
					}
				});
			}
		});
	}
}
//pzen quickview
$(document).ready(function() {
	// Support for AJAX loaded modal window.
	$('[data-toggle="modal"].quickview-action').click(function(e) {
		e.preventDefault();
		if($('#quickViewModal').length > 0 ){
			$('.modal-backdrop').remove();
			$('#quickViewModal').remove();
		}
		var datatarget=$(this).attr("data-target");
		var dataurl=$(this).attr("data-target-href");
		datatarget.replace('#','');
		$.get(dataurl, function(data) {
			if($('#quickViewModal').length > 0 ){
				$("#quickViewModal .product-popup-content").html(data);
				$('#quickViewModal').modal('show');
			}else{
				$('<div class="modal modal-popup modal-quickview fade" id="quickViewModal"><div class="modal-dialog modal-lg"><div class="modal-content"><div class="modal-header"><button aria-label="Close" data-dismiss="modal" class="close" type="button"><i class="fa fa-times"></i></button></div><div class="product-popup"><div class="product-popup-content">' + data + '</div></div></div></div></div>').modal();
			}
			
		}).success();
	});
});
//eof pzen quickview
/*-- Sidebar Category DropDown --*/
$('#cate-toggle li.has-submenu > .cat-lnk > .holder').on('click', function(){
	var element = $(this).parent('.cat-lnk').parent('li');
	if (element.hasClass('open')) {
		element.removeClass('open');
		element.find('li').removeClass('open');
		element.find('ul').slideUp();
	}
	else {
		element.addClass('open');
		element.children('ul').slideDown();
		element.siblings('li').children('ul').slideUp();
		element.siblings('li').removeClass('open');
		element.siblings('li').find('li').removeClass('open');
		element.siblings('li').find('ul').slideUp();
	}
});	
/*-- Sidebar Category DropDown --*/
// Subscription popupbox model
function getCookie(c_name) {
    var c_value = document.cookie;
    var c_start = c_value.indexOf(" " + c_name + "=");
    if (c_start == -1) {
        c_start = c_value.indexOf(c_name + "=");
    }
    if (c_start == -1) {
        c_value = null;
    } else {
        c_start = c_value.indexOf("=", c_start) + 1;
        var c_end = c_value.indexOf(";", c_start);
        if (c_end == -1) {
            c_end = c_value.length;
        }
        c_value = unescape(c_value.substring(c_start, c_end));
    }
    return c_value;
}

function setCookie(c_name, value, exdays) {
    var exdate = new Date();
    exdate.setDate(exdate.getDate() + exdays);
    var c_value = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toUTCString());
    document.cookie = c_name + "=" + c_value;
}

function close_pop() {
    setCookie('subscribepop_marcus', true, 365);
    return false;
}

$(document).ready(function($){
    if (!getCookie('subscribepop_marcus')) {
		// show newsletter Modal
		$(window).load(function(){
			"use strict";
			if ($('#newsletterModal').length) {
				var pause = $('#newsletterModal').attr('data-pause');
				setTimeout(function() {
					$('#newsletterModal').modal('show');
				}, pause);
			}
		});
		$('#nomorepopbox').click(function () {
			if($('#nomorepopbox').prop("checked")==true){
				close_pop();
			}else{
				setCookie('subscribepop_marcus', false, -1);
			}
		});
		$('#newsletterModal .close').click(function () {
		   $('#newsletterModal').modal('hide');
		});
    }
});
//EOF Subscription popupbox model