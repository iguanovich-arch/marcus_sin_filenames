/*
 * Posc AjxCart for Zen Cart.
 * WARNING: Do not change this file. Your changes will be lost.
 *
 * @copyright Copyright 2017 Perfectus Inc.
 * Version : Posc AjxCart 1.6
 */
 
 
var popTimer;
function getParameterByName(sParam, url) {
    if (!url) { url = window.location.href; }
    var sPageURL =url;
	    var sURLVariables = sPageURL.split('&');
	    for (var i = 0; i < sURLVariables.length; i++)
	    {
	        var sParameterName = sURLVariables[i].split('=');
	        if (sParameterName[0] == sParam)
	        {
	            return sParameterName[1];
	        }
	    }
}
function setPoscShowOptions(e, products_id, link){
	setPoscAjxloaderClass(e, 'add');
	try {
		jQuery.ajax({
			type : 'POST',
			url  : link,
			dataType : 'HTML',
			data : {'posc_action': 'show','products_id': products_id},
			success :function(data){
				setPoscAjxQck(e, data, 'qck');
				setPoscAjxloaderClass(e, 'remove');
			},
			error: function(xhr, textStatus, errorThrown) {
				var err = eval("(" + xhr.responseText + ")");
				setPoscAjxQck(e, "Error: " + xhr.status + ": " + xhr.statusText);
				setPoscAjxloaderClass(e, 'remove');
			}
		});
	} catch (e) {
	}
	return false;
}
function setPoscAjxloaderClass(e, act, t){
	var act = act || 'add';
	var t	= t || false;   
	if(act=='add'){
		$('body').addClass("posc-ajx-loader");
		if(t=='pinfo' ){
			e.addClass("posc-ajxldr");
		}else if(t=='cartpage' ){
			e.addClass("posc-tbl-ajxldr");
		}else if(t=='rcart'){
			$(e).parents(".poscajx-minicart").addClass("posc-ajxldr");
			$(e).parents("#cartContentsDisplay").addClass("posc-ajxldr");
		}else{
			$(e).parents('.product-wrapper').addClass("posc-ajxldr");
		}
	}else if(act=='remove'){
		$('body').removeClass("posc-ajx-loader");
		if(t=='pinfo' ){
			e.removeClass("posc-ajxldr");
		}else if(t=='cartpage' ){
			e.removeClass("posc-tbl-ajxldr");
		}else if(t=='rcart'){
			$(e).parents("#cartContentsDisplay").removeClass("posc-ajxldr");
		}else{
			$(e).parents('.product-wrapper').removeClass("posc-ajxldr");
		}
	}
}
//set AjxAddtoCart
function setPoscAjxAddCart(e, products_id, action, qty, d, t){
	var action = action || 'add';
	var qty = qty || '1';
	
	setPoscAjxloaderClass(e, 'add', t);
	try {
		jQuery.ajax({
			type : 'POST',
			url  : posc_ajxcart_file,
			dataType : 'json',
			data : (((typeof d!="undefined") && d!='')? d:{'posc_action': action,'products_id': products_id, 'qty': qty}),
			success :function(data){
				setPoscAjxData(e, data, action);
				setPoscAjxloaderClass(e, 'remove', t);
			},
			error: function(xhr, textStatus, errorThrown) {
				var err = eval("(" + xhr.responseText + ")");
				setPoscAjxQck(e, "Error: " + xhr.status + ": " + xhr.statusText);
				setPoscAjxloaderClass(e, 'remove', t);
			}
		});
	} catch (e) {
	}
	return false;
}
function setPoscAjxRemoveCart(e, pid, action){
	var action = action || 'remove';
	setPoscAjxAddCart(e, pid, action, 0, '', 'rcart');
}
function setPoscAjxData(e, data, action){
	
	if(data.status == 'error'){
		setPoscAjxHandPop(data);
	}else{
		if(data.minicart){
			$(".poscMiniCartCount").html(data.cartcontent.cartCount);
			$(".poscAjxCart").html(data.minicart);
		}
		if(data.cartcontent){
			$("#mposc-ajxcart-action .cart-count").html(data.cartcontent.cartCount);
			$('#cartSubTotal').html(data.cartcontent.subTotal);
			$('.cartTotalsDisplay').html(data.cartcontent.mainTotals);
			$('.mob-cart .count').html(data.cartcontent.cartCount);
			if(data.cartcontent.shippingEstimator){
				$('.shippingEstimatorCont').html(data.cartcontent.shippingEstimator);
			}
		}
		
		if(action == 'prodinfo-add'){
			var pcrtup = $(data.popcontent).find(".qty-in-cart").text();
			if(typeof pcrtup != "undefined"){
				if(pcrtup!=''){
					if($('#cartAdd > p').length > 0){
						$('#cart-box #cartAdd > p').html(pcrtup);
					}else{
						$('#cart-box #cartAdd').prepend('<p class="qty-in-cart">'+pcrtup+'</p>');
					}
				}
			}
		}
		
		if(action=='multicart-update'){
			if(data.cartcontent.cartCount==0){ location.reload();}
			if(data.cartuproduct){
				$.each( data.cartuproduct, function( key, value ) {
					$("#cartContentsDisplay tr").not(".tableHeading").each(function(index){
						if(key==index){
							$(this).find('.cartQuantity input[name="cart_quantity[]"]').val(value.cartQuantity);
							$(this).find(".cartUnitDisplay").html(value.cartUnitDisplay);
							$(this).find(".cartTotalDisplay").html(value.cartTotalDisplay);
						}
					});
				});
			
				if(data.msg.status!='success'){
					setPoscAjxHandPop(data);
				}
			}
		}else if(action=='cart-update'){
			if(data.cartcontent.cartCount==0){ location.reload();}
			if(data.cartuproduct){
				$.each( data.cartuproduct, function( key, value ) {
					$("#cartContentsDisplay tr").not(".tableHeading").each(function(index){
						var cpid = $(this).find('input[name="products_id[]"]').val();
						if(cpid==value.cartProductsId){
							$(this).find('.cartQuantity input[name="cart_quantity[]"]').val(value.cartQuantity);
							$(this).find(".cartUnitDisplay").html(value.cartUnitDisplay);
							$(this).find(".cartTotalDisplay").html(value.cartTotalDisplay);
						}
					});
				});
				if(data.msg.status!='success'){
					setPoscAjxHandPop(data);
				}
			}
		}else if(action=='cart-remove' || action=='remove' ){
			// no action
		}else{
			setPoscAjxHandPop(data);
		}
	}
	//remove cart page products
	if(action=='remove' || action=='cart-remove' ){
		$('#cartContentsDisplay').find("tr").each(function(){		
			id=$(this).find('[name="products_id[]"]').val();
			if(typeof id  !== "undefined"){
				if(data.rid==id){
					removePoscCartRow($(this), data, action);
				}
				
			}
		});
	}
}
function setPoscAjxHandPop(data){
	var popEtimer = 10000;
	if (popTimer) clearTimeout(popTimer);
	if(data.pop_timer){	popEtimer = data.pop_timer;	}
	if(data.popcontent){
		if($("#poscajx-wrapper").length){
			$("#poscajx-wrapper").modal('show');
			$("#quickViewModal").modal("hide");
			$('body').addClass("posc-ajxmodal-open");
			setTimeout(function(){$("#poscajx-wrapper").removeClass('posc-qck');},50);
			if(data.popcontent){
				$("#poscajx-wrapper .poscajxinner-content").html(data.popcontent);
			}
		popTimer =	setTimeout(function(){
			if (popEtimer == -1) {
				clearTimeout(popTimer);
			} 
			closePoscAjxPopup(); 
			}, popEtimer);
		}
	}
}
function setPoscAjxQck(e, data, action){
	var action = action || false;
	if($("#poscajx-wrapper").length){
		if(action=='qck'){
			$("#poscajx-wrapper").addClass('posc-qck');
		}
		$("#poscajx-wrapper").modal('show');
		if(data){
			$("#poscajx-wrapper .poscajxinner-content").html(data);
		}
	}
}
function closePoscAjxPopup(){
	clearTimeout(popTimer);
	setTimeout(function(){$("#poscajx-wrapper").removeClass('posc-qck');},400);
	$("#poscajx-wrapper").modal('hide');
	$('body').removeClass("posc-ajxmodal-open");
}
function removePoscCartRow(e, data, action){
	var action = action || false;
	var data = data || false;
	$("#poscajx-wrapper").modal('hide');
	if(e){e.fadeOut(300, function() { $(this).remove(); });}
	if(data){if(data.cartcontent.cartCount==0){ location.reload();}	}
	
	closePoscAjxPopup();
}
function closeMposcmenuPopup(){
	clearTimeout(popTimer);
	setTimeout(function(){$("#poscajx-wrapper").removeClass('posc-qck');},400);
	$("#poscajx-wrapper").fadeOut(300);
	$('body').removeClass("posc-ajxpop-open");
}
function MposcFlyout(MposcClickFn, MposcContainer, MposcAction){
	var eventtype = checkMposcMobile() ? 'touchstart' : 'click';
	var ajaxcart_container = $(MposcContainer);
	var MposcClickFn = function(event) {
		var targetElement = event.target || event.srcElement;
		if(!hasMposcParentClass( targetElement, 'mposc-flyout-content')) {
			resetMposcFlyout();
			document.removeEventListener( eventtype, MposcClickFn );
		}
	}
	$('body').on('click', MposcAction, function(e) {
		e.preventDefault();
		var ajxcart_effect = $(this).attr( 'data-effect' );
		if($('html').hasClass('mposc-flyout-open')) {
			$('html').removeClass('mposc-flyout-open');
			$(ajaxcart_container).removeClass(ajxcart_effect);
			$(ajaxcart_container).removeClass('mposc-flyout-active');			
		} else {
			$('html').addClass('mposc-flyout-open');
			$(ajaxcart_container).addClass(ajxcart_effect);
			$(ajaxcart_container).addClass('mposc-flyout-active');			
			setTimeout(function() {
				document.addEventListener( eventtype, MposcClickFn);  
			}, 20); 
		}
		
	});
	jQuery('.close-flyout').click(function() {
		resetMposcFlyout();
		document.removeEventListener( eventtype, MposcClickFn );
	}); 
}
function checkMposcMobile() {
		var check = false;
		(function(a){if(/(android|ipad|playbook|silk|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))check = true})(navigator.userAgent||navigator.vendor||window.opera);
		return check;
}
function resetMposcFlyout() {
	jQuery('html').removeClass('mposc-flyout-open');
	if(jQuery('.mposc-flyout-container').hasClass('mposc-flyout-active')){
		jQuery('.mposc-flyout-container').removeClass('mposc-flyout-active');
	}
}
function hasMposcParentClass(e, classname ) {
	if(e === document) return false;
	if( classie.has( e, classname ) ) {
		return true;
	}
	return e.parentNode && hasMposcParentClass( e.parentNode, classname );
}
function compareNew(obj, action) {
	jQuery.ajax({type: "POST", dataType : 'json', cache: false, data:{'compare_id': obj, 'com_action': action,'msg':'yes'}, url: "posc_ajax_compare.php", success: function(data){ setPoscAjxHandPop(data); }
	});
}
/*!
 * classie v1.0.1
 */
(function(window) {
	'use strict';
	function classReg( className ) {
	  return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
	}
	var hasClass, addClass, removeClass;

	if ( 'classList' in document.documentElement ) {
			hasClass = function( elem, c ) {
			return elem.classList.contains( c );
		};
		addClass = function( elem, c ) {elem.classList.add( c );};
		removeClass = function( elem, c ) {elem.classList.remove( c );};
	}else {
		hasClass = function( elem, c ) {
			return classReg( c ).test( elem.className );
		};
		addClass = function( elem, c ) {
			if ( !hasClass( elem, c ) ) {
				elem.className = elem.className + ' ' + c;
			}
		};
		removeClass = function( elem, c ) {
			elem.className = elem.className.replace( classReg( c ), ' ' );
		};
	}
	function toggleClass( elem, c ) {
		var fn = hasClass( elem, c ) ? removeClass : addClass;
		fn( elem, c );
	}	
	var classie = {hasClass: hasClass, addClass: addClass, removeClass: removeClass, toggleClass: toggleClass, has: hasClass, add: addClass, remove: removeClass, toggle: toggleClass};
	if ( typeof define === 'function' && define.amd ) { define( classie ); } else if ( typeof exports === 'object' ) { module.exports = classie; } else { window.classie = classie; }
})( window );