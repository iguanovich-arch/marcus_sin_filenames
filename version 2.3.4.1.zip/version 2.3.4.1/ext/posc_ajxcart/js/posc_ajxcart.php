<?php 
/**
 * Posc AjxCart for Zen Cart.
 * WARNING: Do not change this file. Your changes will be lost.
 *
 * @copyright Copyright 2017 Perfectus Inc.
 * Version : Posc AjxCart 1.6
 */
?>
<?php if(POSC_AJXCART_STATUS=='True'){
$catalog_path = (($request_type=='SSL')?HTTPS_SERVER.DIR_WS_HTTPS_CATALOG:HTTP_SERVER.DIR_WS_CATALOG);
?>
<style type="text/css">
.poscajx-wrapper .poscajx-pop-content {max-width: <?php echo (POSC_AJXCART_POPUP_WIDTH!='auto')? POSC_AJXCART_POPUP_WIDTH.'px' : POSC_AJXCART_POPUP_WIDTH ; ?>;max-height: <?php echo (POSC_AJXCART_POPUP_HEIGHT!='auto')? POSC_AJXCART_POPUP_HEIGHT.'px' : POSC_AJXCART_POPUP_HEIGHT ; ?>;}
.poscajx-wrapper .image > img{max-width: <?php echo (POSC_AJXCART_POPUP_IMAGE_WIDTH!='auto')? POSC_AJXCART_POPUP_IMAGE_WIDTH.'px' : POSC_AJXCART_POPUP_IMAGE_WIDTH ; ?>;max-height: <?php echo (POSC_AJXCART_POPUP_IMAGE_HEIGHT!='auto')? POSC_AJXCART_POPUP_IMAGE_HEIGHT.'px' : POSC_AJXCART_POPUP_IMAGE_HEIGHT ; ?>;}
</style>
<script type="text/javascript">
var posc_ajxcart_file = '<?php echo $catalog_path.FILENAME_POSC_AJX_CART; ?>';
jQuery(document).ready(function(){
	jQuery("body").on("click","#posccontinue_shopping, .poscajx-close",function(){
		closePoscAjxPopup();
	});
	jQuery("body").on("click", "#poscgo-cart",function(){
		parent.location.href="<?php echo tep_href_link('shopping_cart.php', '', 'SSL'); ?>";
	});
	jQuery("body").on("click", "#pos-goto-checkout",function(){
		parent.location.href="<?php echo tep_href_link('checkout_shipping.php', '', 'SSL'); ?>";
	});
	jQuery('body').on('click','.qty_box .ibtn.inc', function(){
		var oldVal = jQuery('.cart_info input[name="cart_quantity"]').val();
		var newVal = (parseInt(jQuery('.cart_info input[name="cart_quantity"]').val(),10) +1);
		jQuery('.cart_info input[name="cart_quantity"]').val(newVal).trigger("keyup");;
	});

	jQuery('body').on('click','.qty_box .ibtn.dec', function(){
	var oldVal = jQuery('.cart_info input[name="cart_quantity"]').val();
    var newVal = (parseInt(jQuery('.cart_info input[name="cart_quantity"]').val(),10) -1);
    if (oldVal > 1) {
            var newVal = parseFloat(oldVal) - 1;
        } else {
            var newVal = 1;
        }
		jQuery('.cart_info input[name="cart_quantity"]').val(newVal).trigger("keyup");;
	});
});
var $ = jQuery.noConflict();
jQuery(function(){
	var timer = 0;
	var poscajx_wrapper='<section id="poscajx-wrapper" class="poscajx-wrapper modal  modal--bg fade"><div class="modal-dialog white-modal"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal" aria-hidden="true"><span class="icon icon-clear material-icons"></span></button></div><div class="poscajx-content"><div class="poscajxinner-content"></div></div></div></div></section>';
	if(!$("#poscajx-wrapper").length){
		$('body').append(poscajx_wrapper);
	}
	
	//BOF Qty validation
    $('body').on('keydown', 'input[name="cart_quantity"], input[name="cart_quantity[]"]', function (e) {
		
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 && e.keyCode <= 40)) {
                 // let it happen, don't do anything
                 return;
        }
		
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });
	$('body').on('blur', 'input[name="cart_quantity"], input[name="cart_quantity[]"]', function (e) {
		var cur_val = parseInt($(this).val());
		var min_val = parseInt($(this).attr('min'));
		var max_val = parseInt($(this).attr('max'));
		if(isNaN(cur_val)){
			$(this).val(min_val); 
		}
    });
	$('body').on('change keyup', 'input[name="cart_quantity"], input[name="cart_quantity[]"]', function (e) {
		var cur_val = parseInt($(this).val());
		var min_val = parseInt($(this).attr('min'));
		var max_val = parseInt($(this).attr('max'));
		if(cur_val < min_val){
			$(this).val(min_val); 
		}
		if(cur_val > max_val){
			$(this).val(max_val);
		}
    });
	//EOF Qty validation
	
	//mobile-ajaxcart
	  MposcFlyout('bodyAjxCartClickFn','.ajxcart-container', '.mposc-ajxcart-action');
	
	// product Listing submit cart action
	$('body').on('submit', '#productListing form[name="cart_quantity"]', function(e){
		e.preventDefault();
		data = new Array();
		data.push($(this).serialize());
		data.push("qty="+$('input[name="cart_quantity"]').val());
		data.push("posc_action=prodinfo-add");
		data = data.join("&");
		setPoscAjxAddCart($(this), '', '', '', data);
		
	});
	
	// product info submit cart action
	$('body').on('submit', '#productGeneral form[name="cart_quantity"]', function(e){
	
		e.preventDefault();
		data = new Array();
		data.push($(this).serialize());
		data.push("qty="+$('input[name="cart_quantity"]').val());
		data.push("posc_action=prodinfo-add");
		data = data.join("&");
		setPoscAjxAddCart($(this), '', 'prodinfo-add', '', data, 'pinfo');
		
	});
	
	// product Listing Multi add cart
	$('form[name="multiple_products_cart_quantity"]').submit(function(event) {
		event.preventDefault();
		data = new Array();
		data.push($(this).serialize());
		data.push("posc_action=multiprod-add");
		data = data.join("&");
		setPoscAjxAddCart($(this).find("#productListing"), '', '', '', data);
		
	});
	
	// Cart Full Update
	$('body').on('submit', '#shoppingCartDefault form[name="cart_quantity"]', function(e){
		e.preventDefault();
		data = new Array();
		data.push($(this).serialize());
		data.push("posc_action=multicart-update");
		data = data.join("&");
		setPoscAjxAddCart($("#shoppingCartDefault"), '', action='multicart-update', '', data, 'cartpage');
	});
	
	//Cart Single Update
	$('.cartQuantityUpdate input').click(function(e) {
		e.preventDefault();
		qty = parseInt($(this).parents('tr').find('input[name="cart_quantity[]"]').val());
		pid = $(this).siblings('input[name="products_id[]"]').val();
		data = new Array();
		data.push($('#shoppingCartDefault form[name="cart_quantity"]').serialize());
		data.push("suid="+pid);
		data.push("posc_action=cart-update");
		data = data.join("&");
		
		setPoscAjxAddCart($(this).parent().parent(), pid, action='cart-update', '', data, 'cartpage');	
	});
	
	// Cart delete action
	$('.cartRemoveItemDisplay a').click(function(event) {
		event.preventDefault();
		var pid=getParameterByName('products_id', $(this).attr('href'));
		if(pid){
			setPoscAjxRemoveCart($(this).parent().parent(), decodeURIComponent(pid), 'cart-remove','', '', 'cartpage');
		}
	});
});
</script>
<?php } ?>